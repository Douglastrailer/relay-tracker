// Platform contact details shown on Contact, sign-up help, and inactive-account
// screens. Change them here only.
const PLATFORM_CONTACT = { email: 'dustinashford06@gmail.com', phone: '+1 (417) 203-0461' };
function applyPlatformContact(){
  document.querySelectorAll('[data-contact="email"]').forEach(a => { a.textContent = PLATFORM_CONTACT.email; a.href = 'mailto:' + PLATFORM_CONTACT.email; });
  document.querySelectorAll('[data-contact="phone"]').forEach(el => { el.textContent = PLATFORM_CONTACT.phone; });
}
applyPlatformContact();

// surface any uncaught error instead of failing silently
async function logErrorToServer(message, stack){
  try{
    if(!sb || typeof session === 'undefined' || !session) return;
    await sb.from('error_logs').insert([{
      message: String(message).slice(0, 2000),
      stack: stack ? String(stack).slice(0, 4000) : null,
      page_url: window.location.href,
      user_id: session.id,
      user_role: session.role
    }]);
  } catch(e){ /* never let error logging itself cause more errors */ }
}

window.addEventListener('error', function(e){
  const box = document.getElementById('fatalError');
  box.style.display = 'block';
  box.textContent = 'Something broke: ' + (e.message || 'unknown error') + (e.filename ? ' (' + e.filename.split('/').pop() + ':' + e.lineno + ')' : '');
  logErrorToServer(e.message, e.error && e.error.stack);
});

// Unhandled promise rejections are extremely common in an app this
// full of async/await Supabase calls, and were previously invisible
// entirely — a failed request could just silently do nothing.
window.addEventListener('unhandledrejection', function(e){
  const reasonMsg = e.reason && e.reason.message ? e.reason.message : String(e.reason);
  const box = document.getElementById('fatalError');
  box.style.display = 'block';
  box.textContent = 'Something broke: ' + reasonMsg;
  logErrorToServer(reasonMsg, e.reason && e.reason.stack);
});

// ================= Supabase connection =================
const SUPABASE_URL = 'https://okcogufppsubntrchfuf.supabase.co';
const SUPABASE_KEY = 'sb_publishable_Z8qgdFjVetqSOfmZKhxkpQ_XX2tYHDp';
let sb = null;

(function checkEnv(){
  const box = document.getElementById('fatalError');
  const problems = [];
  if(typeof window.supabase === 'undefined') problems.push('The Supabase library failed to load — check your internet connection and reload.');
  if(typeof L === 'undefined') problems.push('The map library failed to load — check your internet connection and reload.');
  if(problems.length){ box.style.display = 'block'; box.textContent = problems.join(' '); return; }
  sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
})();

// ================= helpers =================
function milesBetween(lat1,lon1,lat2,lon2){
  const R=3958.8;
  const dLat=(lat2-lat1)*Math.PI/180, dLon=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dLat/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}
// In-shop jobs never travel, so "en_route" is never a valid destination
// for one — same rule already enforced by only showing "Start job" (no
// "Heading there" step) on the mechanic's own in-shop job cards. This
// keeps drag-and-drop from creating a state the rest of the app treats
// as impossible.
// ---- Repair order statuses (Phase 1) ----
// 'complete' keeps its original stored name so older screens and data keep
// working; people see it as "Completed".
const STATUS_LABELS = {
  new:'New', assigned:'Assigned', en_route:'En route', on_site:'On site',
  diagnosing:'Diagnosing', waiting_approval:'Waiting for approval', waiting_parts:'Waiting for parts',
  repairing:'Repairing', quality_control:'Quality check', complete:'Completed',
  invoiced:'Invoiced', paid:'Paid', cancelled:'Cancelled'
};
const STATUS_ORDER = Object.keys(STATUS_LABELS);
const CLOSED_STATUSES = ['complete','invoiced','paid','cancelled'];   // not on the board
const DONE_STATUSES = ['complete','invoiced','paid'];                  // finished work (history, analytics)
const WORKING_STATUSES = ['on_site','diagnosing','repairing','quality_control'];
const MECHANIC_STATUSES = ['en_route','on_site','diagnosing','waiting_parts','repairing','quality_control','complete'];
function statusLabel(status){ return STATUS_LABELS[status] || String(status || '').replace(/_/g,' '); }
function isClosedStatus(status){ return CLOSED_STATUSES.includes(status); }
// Board columns show *why* a job is where it is.
// Redesign R1: the shop board follows the work order from request to invoice.
const BOARD_COLUMNS = {
  new: ['new'],
  estimate: ['diagnosing'],
  approval: ['waiting_approval'],
  assigned: ['assigned'],
  progress: ['en_route','on_site','repairing','quality_control'],
  waiting: ['waiting_parts'],
  completed: ['complete'],
  invoiced: ['invoiced']
};
function boardColumnFor(status){
  for(const col in BOARD_COLUMNS){ if(BOARD_COLUMNS[col].includes(status)) return col; }
  return 'new';
}
// Status a job gets when dropped into a column; null = not allowed.
// Dropping inside a column keeps the more specific status it already has.
function kanbanDropStatus(jobType, currentStatus, column){
  if(!BOARD_COLUMNS[column]) return null;
  if(column === 'invoiced') return null;                          // invoices are created, not dragged
  if(BOARD_COLUMNS[column].includes(currentStatus)) return currentStatus;
  if(column === 'progress') return jobType === 'mobile' && ['new','assigned'].includes(currentStatus) ? 'en_route' : 'repairing';
  return { new:'new', estimate:'diagnosing', approval:'waiting_approval', assigned:'assigned', waiting:'waiting_parts', completed:'complete' }[column];
}
const PRIORITY_LABELS = { low:'Low', normal:'Normal', high:'High', urgent:'Urgent' };
function roChipsHtml(j){
  let out = '';
  if(j.ro_number) out += `<span class="ro-num">${esc(j.ro_number)}</span>`;
  if(j.priority && j.priority !== 'normal') out += `<span class="prio-chip prio-${esc(j.priority)}">${esc(PRIORITY_LABELS[j.priority] || j.priority)}</span>`;
  if(j.safety_issue) out += `<span class="prio-chip prio-safety">Safety</span>`;
  if(j.drivable === false) out += `<span class="prio-chip prio-nodrive">Not drivable</span>`;
  if(j._helping) out += `<span class="prio-chip prio-low">Helping</span>`;
  if(j.warranty_claim_status === 'pending_review') out += `<span class="prio-chip prio-high" title="This unit had an earlier repair that may still be under warranty">Warranty?</span>`;
  else if(j.warranty_claim_status === 'warranty') out += `<span class="prio-chip prio-low">Warranty</span>`;
  return out ? `<div class="ro-chips">${out}</div>` : '';
}

const BOARD_COLUMN_LABELS = { new:'New', estimate:'Estimate', approval:'Waiting for approval', assigned:'Assigned', progress:'In progress', waiting:'Waiting for parts', completed:'Completed', invoiced:'Invoiced' };
let draggedJobId = null;

// One place that moves a job to a column — used by dragging AND by the "Move to…" menu,
// so a phone with no drag gets exactly the same behaviour, including Undo.
async function moveJobToColumn(jobId, jobType, currentStatus, column){
  const targetStatus = kanbanDropStatus(jobType, currentStatus, column);
  if(!targetStatus){ relayNotice(column === 'invoiced' ? 'Open the work order and create the invoice from it.' : "That move isn't allowed for this job.", { kind: 'info' }); return false; }
  if(targetStatus === currentStatus) return false;
  const { error } = await sb.from('jobs').update({ status: targetStatus, updated_at: new Date().toISOString() }).eq('id', jobId);
  if(error){ relayFail(error, 'Could not move the job'); return false; }
  if(typeof notifyKick === 'function') notifyKick();
  refreshShopData();
  if(typeof undoToast === 'function') undoToast('Moved to ' + statusLabel(targetStatus), async () => {
    const { error: e } = await sb.from('jobs').update({ status: currentStatus, updated_at: new Date().toISOString() }).eq('id', jobId);
    if(e) return e.message; refreshShopData();
  });
  return true;
}

function wireKanbanDragDrop(board){
  board.querySelectorAll('.job-card').forEach(card=>{
    if(card.dataset.dnd) return; card.dataset.dnd = '1';   // set up once (refreshes used to add a copy every time)
    card.addEventListener('dragstart', ()=>{
      draggedJobId = Number(card.dataset.job);
      card.classList.add('dragging');
    });
    card.addEventListener('dragend', ()=>{
      card.classList.remove('dragging');
      draggedJobId = null;
    });
  });

  board.querySelectorAll('.kanban-col-list').forEach(colList=>{
    if(colList.dataset.dnd) return; colList.dataset.dnd = '1';   // set up once: one drop moves the job once
    const column = colList.id.replace('kanban-', '');
    colList.addEventListener('dragover', (e)=>{ e.preventDefault(); colList.classList.add('drag-over'); });
    colList.addEventListener('dragleave', ()=> colList.classList.remove('drag-over'));
    colList.addEventListener('drop', async (e)=>{
      e.preventDefault();
      colList.classList.remove('drag-over');
      if(draggedJobId === null) return;
      const card = board.querySelector(`.job-card[data-job="${draggedJobId}"]`);
      const jobType = card ? card.dataset.jobtype : 'mobile';
      const currentStatus = card ? card.dataset.status : '';
      await moveJobToColumn(draggedJobId, jobType, currentStatus, column);
    });
  });
}

function jobStatusBadge(status){
  // Repair progress and billing are different things: a finished job that has been invoiced or paid shows
  // "Completed" plus a separate billing badge. (The stored status values are unchanged.)
  if(status === 'invoiced' || status === 'paid'){
    return `<span class="badge-pair"><span class="badge arrived"><span class="bd"></span>Completed</span><span class="badge bill ${status}"><span class="bd"></span>${status === 'paid' ? 'Paid' : 'Invoiced'}</span></span>`;
  }
  const label = esc(statusLabel(status));
  let cls = 'arrived';
  if(status === 'new' || status === 'assigned') cls = 'pending';
  else if(status === 'en_route') cls = 'live';
  else if(WORKING_STATUSES.includes(status)) cls = 'onsite';
  else if(status === 'waiting_approval' || status === 'waiting_parts') cls = 'waiting';
  else if(status === 'cancelled') cls = 'cancelled';
  return `<span class="badge ${cls}"><span class="bd"></span>${label}</span>`;
}
// A small, consistent icon set replacing emoji throughout the app.
// Stroke-based, currentColor, so every icon automatically matches
// whatever text color it sits in — no separate light/dark variants
// needed. Kept to exactly the set the app actually uses, not a full
// icon library, since anything unused is just dead weight.
const ICONS = {
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z"/>',
  satellite: '<path d="M13 7l4 4-1.5 1.5L11 8.5 13 7z"/><path d="M8 12l4 4-4 4-4-4 4-4z"/><path d="M15.5 4.5L19.5 8.5"/><path d="M3 21l3-3"/>',
  map: '<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2z"/><path d="M9 4v14M15 6v14"/>',
  chat: '<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
  paperclip: '<path d="M21.4 11.5l-9.2 9.2a5.5 5.5 0 0 1-7.8-7.8l9.2-9.2a3.5 3.5 0 0 1 5 5l-9.2 9.2a1.5 1.5 0 0 1-2.1-2.1l8.5-8.5"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h6M9 17h6"/>',
  alert: '<path d="M10.3 3.9l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.7-3.1l-8-14a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
  compass: '<circle cx="12" cy="12" r="10"/><path d="M16.2 7.8l-2.1 6.3-6.3 2.1 2.1-6.3z"/>',
  megaphone: '<path d="M3 11v2a2 2 0 0 0 2 2h1l4 4V5L6 9H5a2 2 0 0 0-2 2z"/><path d="M15 8a3 3 0 0 1 0 8M19 5a8 8 0 0 1 0 14"/>',
  building: '<path d="M6 22V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v18"/><path d="M9 22V16h6v6"/><path d="M9 7h1M14 7h1M9 11h1M14 11h1"/>',
  key: '<circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.6 12.4L20 3M17 6l3 3M13.5 9.5l3 3"/>',
  checkCircle: '<circle cx="12" cy="12" r="10"/><path d="M8.5 12.5l2.5 2.5 5-5"/>',
  xCircle: '<circle cx="12" cy="12" r="10"/><path d="M9 9l6 6M15 9l-6 6"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
};
function icon(name, size){
  const px = size || 16;
  return `<svg width="${px}" height="${px}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-3px;">${ICONS[name] || ''}</svg>`;
}

function pinIcon(cls){
  return L.divIcon({ className:'', html:`<div class="relay-pin ${cls}"></div>`, iconSize:[16,16], iconAnchor:[8,8] });
}
// Adds the default street layer plus a satellite toggle to any Leaflet
// map — shared by all 6 map instances in the app instead of repeating
// tile-layer setup six times. Esri World Imagery is free and needs no
// API key, same reason OpenStreetMap was chosen for the street layer —
// no billing account to set up just to show a map.
function addBaseMapToggle(map){
  const streetLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom:18 }).addTo(map);
  const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom:18, attribution:'Tiles &copy; Esri'
  });
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'map-satellite-toggle';
  btn.innerHTML = icon('satellite') + ' Satellite';
  L.DomEvent.disableClickPropagation(btn); // don't let clicking the button also register as a map click (e.g. dropping a pin)
  btn.onclick = ()=>{
    if(map.hasLayer(satelliteLayer)){ map.removeLayer(satelliteLayer); map.addLayer(streetLayer); btn.innerHTML = icon('satellite') + ' Satellite'; }
    else{ map.removeLayer(streetLayer); map.addLayer(satelliteLayer); btn.innerHTML = icon('map') + ' Map'; }
  };
  map.getContainer().appendChild(btn);
  return { streetLayer, satelliteLayer };
}
// The shop's own document number (INV-0042 / EST-0007); older rows fall back to #id.
function docNo(d){ return d && d.doc_number ? d.doc_number : '#' + (d ? d.id : ''); }
function esc(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function showCompleteToast(job){
  const el = document.getElementById('completeToast');
  const sub = document.getElementById('completeToastSub');
  let durText = '';
  if(job && job.created_at){
    const mins = Math.round((Date.now() - new Date(job.created_at).getTime()) / 60000);
    durText = mins < 60 ? `${mins} min` : `${(mins/60).toFixed(1)} hrs`;
  }
  sub.textContent = job ? `${job.customer} — ${job.vehicle}` + (durText ? ` · ${durText}` : '') : '';
  el.classList.remove('hidden');
  clearTimeout(showCompleteToast._t);
  showCompleteToast._t = setTimeout(()=> el.classList.add('hidden'), 4500);
}

// ================= data layer =================
async function fetchMyProfile(userId){
  let { data, error } = await sb.from('profiles').select('id, name, role, company, org_id, active, staff_role, location_id').eq('id', userId).maybeSingle();
  if(error && /location_id/.test(error.message || '')) ({ data, error } = await sb.from('profiles').select('id, name, role, company, org_id, active, staff_role').eq('id', userId).maybeSingle());
  // Before migration 0013 the staff_role column does not exist yet: sign-in must still work.
  if(error && /staff_role/.test(error.message || '')){
    ({ data, error } = await sb.from('profiles').select('id, name, role, company, org_id, active').eq('id', userId).maybeSingle());
  }
  if(error){ console.error('fetchMyProfile', error); return null; }
  return data;
}
async function fetchOrgMechanics(){
  const { data, error } = await sb.from('profiles').select('id, name, active, availability, skills').eq('role','mechanic').eq('org_id', session.orgId);
  if(error){ console.error('fetchOrgMechanics', error); return []; }
  return data || [];
}
async function fetchOrgMembers(){
  const { data: mechanics, error: mechErr } = await sb.from('profiles').select('id, name, active, role, availability, skills').eq('role','mechanic').eq('org_id', session.orgId);
  if(mechErr) console.error('fetchOrgMembers (mechanics)', mechErr);

  // Fleet managers are linked via fleet_shop_links now, not just profiles.org_id,
  // since one fleet manager can belong to multiple shops.
  const { data: fleetLinks, error: fleetErr } = await sb.from('fleet_shop_links').select('profiles:fleet_id(id, name, active, role, company)').eq('org_id', session.orgId);
  if(fleetErr) console.error('fetchOrgMembers (fleet)', fleetErr);
  const fleetMembers = (fleetLinks || []).map(l => l.profiles).filter(Boolean);

  return [...(mechanics || []), ...fleetMembers];
}
// Fleet accounts linked to this shop, for the "Fleet customer" dropdown.
// A job is visible to a fleet only when it is assigned to that fleet here.
async function fetchLinkedFleets(){
  const { data, error } = await sb.from('fleet_shop_links').select('profiles:fleet_id(id, name, company, active)').eq('org_id', session.orgId);
  if(error){ console.error('fetchLinkedFleets', error); return []; }
  return (data || []).map(l => l.profiles).filter(p => p && p.active);
}
function fleetOptionsHtml(fleets, selectedId){
  return '<option value="">No fleet account (only your shop sees it)</option>' +
    fleets.map(f => `<option value="${f.id}" ${f.id === selectedId ? 'selected' : ''}>${esc(f.company || f.name)}${f.company && f.name ? ' (' + esc(f.name) + ')' : ''}</option>`).join('');
}
async function populateFleetSelect(){
  const sel = document.getElementById('njFleet');
  if(!sel) return;
  const current = sel.value;
  sel.innerHTML = fleetOptionsHtml(await fetchLinkedFleets(), current);
}

async function fetchAllProfiles(){
  // Capped: the admin list is paged in the UI, so pulling every account on the platform
  // into the browser is never needed. The exact total comes from a count-only query.
  const { data, error } = await sb.from('profiles').select('id, name, active, company, org_id, role, email, phone').order('created_at', { ascending:true }).limit(1000);
  if(error){ console.error('fetchAllProfiles', error); return []; }
  return data || [];
}
async function fetchAllOrganizations(){
  const { data, error } = await sb.from('organizations').select('id, name, status, created_at').limit(1000);
  if(error){ console.error('fetchAllOrganizations', error); return []; }
  return data || [];
}
async function fetchCompanies(){
  const { data, error } = await sb.from('fleet_shop_links').select('profiles:fleet_id(company)').eq('org_id', session.orgId);
  if(error) return [];
  return [...new Set((data||[]).map(d=>d.profiles && d.profiles.company).filter(Boolean))];
}
// Invoices, embedded with their line items in one round trip via
// PostgREST's foreign-key embedding (invoice_items.invoice_id -> invoices.id).
// Totals are computed client-side from the embedded items rather than
// stored as a column, so there's never a separate total that can drift
// out of sync with the actual line items.
let invoiceLimit = 100;
async function fetchInvoices(){
  const { data, error } = await sb.from('invoices')
    .select('doc_number, id, job_id, kind, source_estimate_id, customer_name, customer_email, customer_address, unit_number, status, notes, created_at, sent_at, paid_at, total, tax_amount, tax_rate, discount_amount, po_number, payment_terms, due_date, approved_by_name, invoice_items(id, description, quantity, unit_price, customer_decision)')
    .eq('org_id', session.orgId)
    .order('created_at', { ascending:false })
    .limit(invoiceLimit);   // newest first; "Load more" asks for the next 100
  if(error){ console.error('fetchInvoices', error); const e = []; e.loadError = error.message || String(error); return e; }   // an error must not look like an empty list
  return data || [];
}
async function fetchJobsForInvoiceLink(){
  const { data, error } = await sb.from('jobs').select('id, customer, vehicle').eq('org_id', session.orgId).order('created_at', { ascending:false }).limit(50);
  if(error) return [];
  return data || [];
}
// Active jobs are naturally small (a handful of open jobs at once) so no
// limit is needed here. Completed history is the one that grows unbounded
// over years of use — this fetches only the N most recent AT THE DATABASE
// LEVEL, instead of the old approach of downloading every job a company has
// ever had and slicing it down in the browser.
// Column list excludes only "created_by" — the one job column never
// actually read anywhere in the app after being set on creation.
const JOB_COLUMNS = 'id, customer, vehicle, mechanic_id, job_type, dest_lat, dest_lng, status, created_at, updated_at, org_id, fleet_profile_id, ro_number, customer_id, unit_id, priority, safety_issue, drivable, complaint, diagnosis, fault_codes, completed_at, requires_authorization, authorized_at, authorized_by_name, authorization_override_at, authorization_override_reason, odometer, warranty_months, warranty_miles, warranty_terms, warranty_claim_status, warranty_source_job_id, warranty_decided_at, warranty_decision_note, accepted_at, declined_at, decline_reason, location_id';
async function fetchActiveJobs(scope){
  let q = sb.from('jobs').select(JOB_COLUMNS).not('status','in','(' + CLOSED_STATUSES.join(',') + ')').order('created_at', { ascending:true });
  // Scoping here is a query-planning aid, not the security boundary — RLS
  // still enforces access underneath regardless of what's passed in. But
  // without it, Postgres can't use idx_jobs_org_status / idx_jobs_mechanic_status
  // at all (the RLS OR-condition across mechanic/org/fleet-link is opaque
  // to the planner on its own) and falls back to scanning every job on the
  // platform on every dashboard refresh — fine at a few thousand rows, a
  // real bottleneck once job history accumulates at real scale.
  if(scope && scope.orgId){ q = q.eq('org_id', scope.orgId); if(typeof locFilter === 'function') q = locFilter(q); }   // the location switcher (R8)
  else if(scope && scope.mechanicId) q = q.eq('mechanic_id', scope.mechanicId);
  else if(scope && scope.orgIds && scope.orgIds.length) q = q.in('org_id', scope.orgIds);
  const { data, error } = await q;
  if(error){ console.error('fetchActiveJobs', error); return []; }
  return data || [];
}
async function fetchCompletedJobs(limit, scope){
  let q = sb.from('jobs').select(JOB_COLUMNS).in('status', DONE_STATUSES).order('updated_at', { ascending:false }).limit(limit);
  if(scope && scope.orgId){ q = q.eq('org_id', scope.orgId); if(typeof locFilter === 'function') q = locFilter(q); }
  else if(scope && scope.mechanicId) q = q.eq('mechanic_id', scope.mechanicId);
  else if(scope && scope.orgIds && scope.orgIds.length) q = q.in('org_id', scope.orgIds);
  const { data, error } = await q;
  if(error){ console.error('fetchCompletedJobs', error); return []; }
  return data || [];
}
async function fetchJobComments(jobId){
  const { data, error } = await sb.from('job_comments').select('*, profiles:author_id(name)').eq('job_id', jobId).order('created_at', { ascending:true });
  if(error){ console.error('fetchJobComments', error); return []; }
  return data || [];
}
async function addJobComment(jobId, body){
  const { error } = await sb.from('job_comments').insert([{ job_id:jobId, author_id:session.id, body }]);
  // 42501 is Postgres's generic "RLS denied this" code — it fires for the rate
  // limit, but also if access to the job changed underneath you mid-session, so
  // the message below stays deliberately non-specific about which one it was.
  if(error && error.code === '42501'){ return { ok:false, blocked:true }; }
  return { ok: !error };
}
function commentsBlockHtml(jobId){
  return `
    <button class="comments-toggle" data-job="${jobId}">${icon('chat')} Chat</button>
    <div class="comments-box hidden" id="comments-${jobId}">
      <div class="comment-list" id="comment-list-${jobId}"></div>
      <div class="comment-form">
        <input type="text" id="comment-input-${jobId}" placeholder="Message...">
        <button id="comment-send-${jobId}">Send</button>
      </div>
    </div>`;
}
const openCommentThreads = new Set();
// The same job can be rendered on more than one tab at once (e.g. the Jobs
// tab's "Completed history" and the History page), which means two
// elements share an id. getElementById only ever returns the first one —
// usually the copy on a hidden tab — so lookups here are scoped to the
// panel next to the button that was clicked, and list renders update
// every copy.
function allById(id){ return document.querySelectorAll('[id="'+id+'"]'); }
function panelForToggle(btn, prefix, jobId){
  const next = btn.nextElementSibling;
  if(next && next.id === prefix + jobId) return next;
  return document.getElementById(prefix + jobId);
}
async function renderCommentList(jobId){
  const listEls = allById('comment-list-'+jobId);
  if(listEls.length === 0) return;
  const comments = await fetchJobComments(jobId);
  const html = comments.length === 0 ? '<div class="empty-note">No messages yet.</div>' :
    comments.map(c => {
      const mine = c.author_id === session.id;
      return `<div class="comment-item ${mine?'mine':''}">
        <div class="cbubble">
          <span class="cauthor">${esc(c.profiles ? c.profiles.name : 'Someone')}</span>
          <div class="cbody">${esc(c.body)}</div>
          <span class="ctime">${new Date(c.created_at).toLocaleTimeString()}</span>
        </div>
      </div>`;
    }).join('');
  listEls.forEach(listEl=>{ listEl.innerHTML = html; listEl.scrollTop = listEl.scrollHeight; });
}
// Keeps an open chat's actual input box alive across a page rebuild,
// instead of destroying it and copying the text back in. Copying text
// back in (the old approach) still resets focus and the on-screen
// keyboard on mobile, which is what was still causing jumpiness —
// this way the exact same DOM element survives, so nothing about it
// ever actually resets: cursor position, focus, even autocomplete state.
function preserveOpenChatNodes(container){
  const preserved = {};
  container.querySelectorAll('.comments-box:not(.hidden)').forEach(box=>{
    const jobId = box.id.replace('comments-', '');
    preserved[jobId] = box;
    box.remove();
  });
  return preserved;
}
function restoreOpenChatNodes(container, preserved){
  Object.keys(preserved).forEach(jobId=>{
    const placeholder = container.querySelector('#comments-'+jobId);
    if(placeholder && preserved[jobId]) placeholder.replaceWith(preserved[jobId]);
  });
}
function wireCommentToggles(container){
  container.querySelectorAll('.comments-toggle').forEach(btn=>{
    const jobId = btn.dataset.job;
    const box = panelForToggle(btn, 'comments-', jobId);
    btn.onclick = ()=>{
      if(!box) return;
      if(box.classList.contains('hidden')) openThread(jobId, box); else closeThread(jobId, box);
    };
    if(openCommentThreads.has(jobId) && box) openThread(jobId, box);
  });
}
const commentDrafts = {};
function openThread(jobId, box){
  box = box || document.getElementById('comments-'+jobId);
  if(!box) return;
  box.classList.remove('hidden');
  openCommentThreads.add(jobId);
  renderCommentList(jobId);
  const input = box.querySelector('#comment-input-'+jobId);
  const send = box.querySelector('#comment-send-'+jobId);
  if(!input || !send) return;
  if(commentDrafts[jobId]) input.value = commentDrafts[jobId];
  input.oninput = ()=>{ commentDrafts[jobId] = input.value; };
  const submit = async ()=>{
    const val = input.value.trim();
    if(!val) return;
    send.disabled = true;
    const result = await addJobComment(jobId, val);
    send.disabled = false;
    if(result.ok){ input.value = ''; delete commentDrafts[jobId]; renderCommentList(jobId); }
    else if(result.blocked){ relayNotice("Message not sent — you may be posting too quickly, or you may no longer have access to this job. Wait a moment and try again, or refresh if it keeps happening.", { kind: 'error' }); }
  };
  send.onclick = submit;
  input.onkeydown = (e)=>{ if(e.key === 'Enter') submit(); };
}
function closeThread(jobId, box){
  box = box || document.getElementById('comments-'+jobId);
  if(box) box.classList.add('hidden');
  openCommentThreads.delete(jobId);
}

// ================= job attachments (photos/files) =================
const openAttachmentThreads = new Set();
function attachmentsBlockHtml(jobId){
  return `
    <button class="comments-toggle" data-attach-job="${jobId}">${icon('paperclip')} Files</button>
    <div class="comments-box hidden" id="attachments-${jobId}">
      <div class="attach-list" id="attach-list-${jobId}"></div>
      <div class="attach-upload-row">
        <select id="attach-type-${jobId}" class="attach-type-select">
          <option value="general">General file</option>
          <option value="before">Before photo</option>
          <option value="after">After photo</option>
        </select>
        <label class="attach-upload-btn">
          + Add
          <input type="file" id="attach-input-${jobId}" accept="image/*,.pdf,.doc,.docx" style="display:none;">
        </label>
      </div>
    </div>`;
}
function photoTypeTag(photoType){
  if(photoType === 'before') return '<span class="doc-kind-tag">BEFORE</span>';
  if(photoType === 'after') return '<span class="doc-kind-tag">AFTER</span>';
  return '';
}
async function fetchAttachments(jobId){
  const { data, error } = await sb.from('job_attachments').select('*, profiles:uploader_id(name)').eq('job_id', jobId).order('created_at', { ascending:true });
  if(error){ console.error('fetchAttachments', error); return []; }
  return data || [];
}
async function renderAttachmentList(jobId){
  const listEls = allById('attach-list-'+jobId);
  if(listEls.length === 0) return;
  const files = await fetchAttachments(jobId);
  if(files.length === 0){ listEls.forEach(el=>{ el.innerHTML = '<div class="empty-note">No files yet.</div>'; }); return; }
  const items = await Promise.all(files.map(async f=>{
    const { data: signed } = await sb.storage.from('job-attachments').createSignedUrl(f.file_path, 3600);
    const url = signed ? signed.signedUrl : '#';
    const isImage = (f.file_type || '').startsWith('image/');
    return `
      <div class="attach-item">
        ${isImage
          ? `<a href="${url}" target="_blank" rel="noopener"><img src="${url}" class="attach-thumb" alt="${esc(f.file_name)}"></a>`
          : `<a href="${url}" target="_blank" rel="noopener" class="attach-file-link">${icon('file')} ${esc(f.file_name)}</a>`}
        <div class="attach-meta">${photoTypeTag(f.photo_type)}${esc(f.profiles ? f.profiles.name : 'Someone')} · ${new Date(f.created_at).toLocaleDateString()}</div>
      </div>`;
  }));
  const html = items.join('');
  listEls.forEach(el=>{ el.innerHTML = html; });
}
function openAttachmentThread(jobId, box){
  box = box || document.getElementById('attachments-'+jobId);
  if(!box) return;
  box.classList.remove('hidden');
  openAttachmentThreads.add(jobId);
  renderAttachmentList(jobId);
  const input = box.querySelector('#attach-input-'+jobId);
  const typeSelect = box.querySelector('#attach-type-'+jobId);
  if(!input) return;
  input.onchange = async ()=>{
    const file = input.files[0];
    if(!file) return;
    if(file.size > 10*1024*1024){ relayNotice('That file is too big — 10MB max.', { kind: 'info' }); input.value=''; return; }
    const photoType = (typeSelect && typeSelect.value) || 'general';
    // Phone photos are 3–10 MB; shrink them (1600 px, JPEG) before upload.
    let upload = file;
    if(/^image\//.test(file.type) && typeof compressImage === 'function'){ try { upload = await compressImage(file); } catch(e){ upload = file; } }
    const path = `${jobId}/${Date.now()}-${upload.name || file.name}`;
    const { error: upErr } = await sb.storage.from('job-attachments').upload(path, upload);
    if(upErr){ relayFail(upErr, 'Upload failed'); input.value=''; return; }
    const { error: metaErr } = await sb.from('job_attachments').insert([{ job_id:jobId, uploader_id:session.id, file_path:path, file_name:upload.name || file.name, file_type:upload.type || file.type, photo_type:photoType }]);
    if(metaErr) console.error('job_attachments insert failed', metaErr);
    input.value = '';
    renderAttachmentList(jobId);
  };
}
function closeAttachmentThread(jobId, box){
  box = box || document.getElementById('attachments-'+jobId);
  if(box) box.classList.add('hidden');
  openAttachmentThreads.delete(jobId);
}
function wireAttachmentToggles(container){
  container.querySelectorAll('[data-attach-job]').forEach(btn=>{
    const jobId = btn.dataset.attachJob;
    const box = panelForToggle(btn, 'attachments-', jobId);
    btn.onclick = ()=>{
      if(!box) return;
      if(box.classList.contains('hidden')) openAttachmentThread(jobId, box); else closeAttachmentThread(jobId, box);
    };
    if(openAttachmentThreads.has(jobId) && box) openAttachmentThread(jobId, box);
  });
}


// ---- Phase 10: data usage ----
// Timers only run while the tab is visible; when someone comes back to a
// hidden tab, one refresh catches it up. (Hidden tabs used to keep
// reloading all day.)
function everyWhileVisible(fn, ms){
  let last = Date.now();
  setInterval(() => { if(document.hidden) return; last = Date.now(); fn(); }, ms);
  document.addEventListener('visibilitychange', () => {
    if(!document.hidden && Date.now() - last > ms){ last = Date.now(); fn(); }
  });
}
function panelVisible(id){ const p = document.getElementById(id); return !!p && !p.classList.contains('hidden'); }
setInterval(()=>{
  if(document.hidden) return;   // open chats refresh only while visible
  openCommentThreads.forEach(jobId => renderCommentList(jobId));
}, 5000);

async function fetchLocation(mechanicId){
  const { data, error } = await sb.from('locations').select('lat, lng, updated_at, status').eq('mechanic_id', mechanicId).maybeSingle();
  if(error || !data) return null;
  return { lat:data.lat, lng:data.lng, updatedAt:new Date(data.updated_at).getTime(), status:data.status };
}
// Fetches locations for MANY mechanics in a single request instead of
// one request per mechanic — critical once you have more than a
// handful of mechanics, since the old per-mechanic loop meant every
// dashboard refresh did N sequential network round-trips.
// every position of this shop's mechanics in one request, asked for by shop (no need to wait for the mechanic list)
async function fetchShopPositions(){
  const { data, error } = await sb.from('locations').select('mechanic_id, lat, lng, updated_at, status').eq('org_id', session.orgId).limit(500);
  if(error) return null;   // the caller falls back to asking by mechanic
  const map = {};
  (data || []).forEach(row => { map[row.mechanic_id] = { lat: row.lat, lng: row.lng, updatedAt: new Date(row.updated_at).getTime(), status: row.status }; });
  return map;
}
async function fetchLocationsFor(mechanicIds){
  const map = {};
  if(!mechanicIds || mechanicIds.length === 0) return map;
  if(!mechanicIds || !mechanicIds.length) return {};
  const { data, error } = await sb.from('locations').select('mechanic_id, lat, lng, updated_at, status').in('mechanic_id', mechanicIds.slice(0, 500));
  if(error){ console.error('fetchLocationsFor', error); return map; }
  (data || []).forEach(row=>{
    map[row.mechanic_id] = { lat:row.lat, lng:row.lng, updatedAt:new Date(row.updated_at).getTime(), status:row.status };
  });
  return map;
}
async function upsertLocation(mechanicId, lat, lng, status){
  const { error } = await sb.from('locations').upsert(
    { mechanic_id:mechanicId, lat, lng, status, is_live:true, updated_at:new Date().toISOString() },
    { onConflict:'mechanic_id' }
  );
  if(error){ console.error('upsertLocation', error); return false; }
  return true;
}
async function updateLocationStatus(mechanicId, status){
  const { error } = await sb.from('locations').update({ status }).eq('mechanic_id', mechanicId);
  return !error;
}

// ================= session =================
let session = null; // { id, name, role, company, orgId }
let watchId = null;
let mechMapObj = null, mechMarker = null;
const mechDestMarkers = {};
let mechActiveJobsCache = []; // last-rendered active jobs, used by the GPS ticker to update distance without a full page rebuild
let appEntered = false;

// ================= public nav (Home / Sign in / Contact) =================
const homeView = document.getElementById('homeView');
const contactView = document.getElementById('contactView');
const publicAuthView = document.getElementById('authView');
const requestView = document.getElementById('requestView');
const navHome = document.getElementById('navHome'), navSignin = document.getElementById('navSignin'), navContact = document.getElementById('navContact');

// A visitor following a shop's shareable link (?request=<org_id>) has no
// account at all — this runs independent of the normal auth flow and,
// when the param is present, takes over the page instead of showing the
// usual logged-out home screen.
const requestOrgId = new URLSearchParams(window.location.search).get('request');
// which location the link belongs to (each location has its own request link); the database checks it is this shop's
const requestLocId = (() => { const v = new URLSearchParams(window.location.search).get('loc'); return /^[0-9]{1,18}$/.test(v || '') ? Number(v) : null; })();
if(requestOrgId){
  homeView.classList.add('hidden');
  requestView.classList.remove('hidden');
  initPublicRequestPage(requestOrgId);
}

let reqServiceType = 'mobile';
let reqChosenPin = null; // { lat, lng, display_name } once a suggestion is picked

function setReqTypeUI(type){
  reqServiceType = type;
  document.getElementById('reqTypeMobileBtn').classList.toggle('active', type === 'mobile');
  document.getElementById('reqTypeInshopBtn').classList.toggle('active', type === 'inshop');
  document.getElementById('reqLocationField').classList.toggle('hidden', type !== 'mobile');
  document.getElementById('reqEtaField').classList.toggle('hidden', type !== 'inshop');
}

// Standalone address autocomplete for the public page — same debounced
// Nominatim lookup pattern as the shop's own job-creation form, but
// suggestions-only, no map/pin-drop. A customer picking their location
// on a phone during a breakdown is better served by "type it, tap the
// right suggestion" than dragging a pin on a small screen.
function initReqAddressAutocomplete(){
  if(initReqAddressAutocomplete.done) return; initReqAddressAutocomplete.done = true;   // attach once
  const input = document.getElementById('reqAddressInput');
  const suggestBox = document.getElementById('reqAddressSuggestions');
  const hint = document.getElementById('reqAddressHint');
  let debounce = null;

  function hideSuggestions(){ suggestBox.classList.add('hidden'); suggestBox.innerHTML = ''; }
  function renderSuggestions(results){
    if(!results || results.length === 0){ hideSuggestions(); return; }
    suggestBox.innerHTML = results.map((r, i) => `<button type="button" class="address-suggestion" data-i="${i}">${esc(r.display_name)}</button>`).join('');
    suggestBox.classList.remove('hidden');
    suggestBox.querySelectorAll('.address-suggestion').forEach(btn=>{
      btn.onclick = ()=>{
        const r = results[Number(btn.dataset.i)];
        reqChosenPin = { lat: parseFloat(r.lat), lng: parseFloat(r.lon), display_name: r.display_name };
        input.value = r.display_name;
        hint.textContent = 'Location set.';
        hideSuggestions();
      };
    });
  }
  input.addEventListener('input', ()=>{
    reqChosenPin = null; // typing again invalidates whatever was picked before
    const query = input.value;
    clearTimeout(debounce);
    if(!query || query.trim().length < 3){ hideSuggestions(); return; }
    debounce = setTimeout(async ()=>{
      try{
        const url = `https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&limit=5&q=${encodeURIComponent(query)}`;
        const res = await fetch(url, { headers: { 'Accept-Language': 'en' } });
        renderSuggestions(await res.json());
      }catch(e){ hideSuggestions(); }
    }, 450);
  });
  document.addEventListener('click', (e)=>{ if(!suggestBox.contains(e.target) && e.target !== input) hideSuggestions(); });
}

async function initPublicRequestPage(orgId){
  const formCard = document.getElementById('requestFormCard');
  const successCard = document.getElementById('requestSuccessCard');
  const invalidCard = document.getElementById('requestInvalidCard');
  const titleEl = document.getElementById('requestTitle');
  const labelEl = document.getElementById('requestShopLabel');

  const { data: orgRows, error: orgErr } = await sb.rpc('get_org_name_for_request', { target_org_id: orgId });
  if(orgErr || !orgRows || orgRows.length === 0){
    formCard.classList.add('hidden');
    invalidCard.classList.remove('hidden');
    return;
  }
  formCard.classList.remove('hidden');
  const shopName = orgRows[0].name;
  titleEl.textContent = `Request service from ${shopName}`;
  labelEl.textContent = shopName.toUpperCase();

  document.getElementById('reqTypeMobileBtn').onclick = ()=> setReqTypeUI('mobile');
  document.getElementById('reqTypeInshopBtn').onclick = ()=> setReqTypeUI('inshop');
  initReqAddressAutocomplete();

  document.getElementById('requestSubmitBtn').onclick = async ()=>{
    const customer_name = document.getElementById('reqCustomerName').value.trim();
    const company_name = document.getElementById('reqCompanyName').value.trim();
    const customer_phone = document.getElementById('reqCustomerPhone').value.trim();
    const customer_email = document.getElementById('reqCustomerEmail').value.trim();
    const vehicle = document.getElementById('reqVehicle').value.trim();
    const issue_description = document.getElementById('reqIssue').value.trim();
    const eta_to_shop = document.getElementById('reqEta').value.trim();
    const errEl = document.getElementById('requestError');
    errEl.textContent = '';

    if(!customer_name){ errEl.textContent = 'Enter your name.'; return; }
    if(!customer_phone && !customer_email){ errEl.textContent = 'Enter a phone number or an email so the shop can reach you.'; return; }
    if(!vehicle){ errEl.textContent = 'Enter your vehicle or unit.'; return; }
    if(!issue_description){ errEl.textContent = "Describe what's going on."; return; }
    if(reqServiceType === 'mobile' && !reqChosenPin){ errEl.textContent = 'Enter your location and pick the exact match from the list.'; return; }
    if(reqServiceType === 'inshop' && !eta_to_shop){ errEl.textContent = 'Let the shop know when you can bring it in.'; return; }

    const payload = {
      org_id: orgId, customer_name,
      company_name: company_name || null,
      customer_phone: customer_phone || null,
      customer_email: customer_email || null,
      vehicle, issue_description,
      job_type: reqServiceType,
    };
    if(reqServiceType === 'mobile'){
      payload.breakdown_lat = reqChosenPin.lat;
      payload.breakdown_lng = reqChosenPin.lng;
      payload.breakdown_address = reqChosenPin.display_name;
    } else {
      payload.eta_to_shop = eta_to_shop;
    }

    const btn = document.getElementById('requestSubmitBtn');
    // Photos (signed-in fleet customers only): uploaded first, so a request never points at a missing photo.
    const pField = document.getElementById('reqPhotosField'), pInput = document.getElementById('reqPhotos');
    if(pField && pInput && pInput.files && pInput.files.length){
      if(pInput.files.length > 5){ errEl.textContent = 'Please choose up to 5 photos.'; return; }
      btn.disabled = true; const paths = [];
      // signed-in fleet customers use their own folder; everyone else (the public link) uses the shop's public folder
      const rid = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-8xxx-xxxxxxxxxxxx'.replace(/x/g, () => Math.floor(Math.random() * 16).toString(16));
      const folder = (typeof session !== 'undefined' && session && session.role === 'fleet') ? orgId + '/' + session.id : orgId + '/public/' + rid();
      for(let i = 0; i < pInput.files.length; i++){
        btn.textContent = 'Uploading photo ' + (i + 1) + ' of ' + pInput.files.length + '…';
        // Shrinking is a nice-to-have: if it fails or stalls (an odd image, a slow phone), send the original.
        let small = pInput.files[i];
        try { if(typeof scanShrink === 'function' && !window.__noShrink) small = (await Promise.race([scanShrink(small), new Promise(r => setTimeout(() => r(null), 8000))])) || pInput.files[i]; } catch(_){ small = pInput.files[i]; }
        const path = folder + '/' + Date.now() + '-' + i + '.jpg';
        const { error: upErr } = await sb.storage.from('request-photos').upload(path, small, { contentType: small.type || 'image/jpeg', upsert: false });
        if(upErr){ errEl.textContent = 'Photo ' + (i + 1) + " couldn't be uploaded (" + upErr.message + '). Remove it or try again.'; btn.disabled = false; btn.textContent = 'Submit request'; return; }
        paths.push(path);
      }
      payload.photo_paths = paths;
    }
    btn.disabled = true; btn.textContent = 'Sending…';
    if(requestLocId) payload.location_id = requestLocId;
    const { error } = await sb.from('work_requests').insert([payload]);
    btn.disabled = false; btn.textContent = 'Submit request';

    if(error){ errEl.textContent = 'Could not send your request — please try again in a moment.'; return; }
    formCard.classList.add('hidden');
    successCard.classList.remove('hidden');
  };
}

function showPublicView(which){
  [homeView, contactView, publicAuthView].forEach(v=>v.classList.add('hidden'));
  [navHome, navSignin, navContact].forEach(b=>b.classList.remove('active'));
  if(which === 'home'){ homeView.classList.remove('hidden'); navHome.classList.add('active'); }
  if(which === 'contact'){ contactView.classList.remove('hidden'); navContact.classList.add('active'); }
  if(which === 'signin'){ publicAuthView.classList.remove('hidden'); navSignin.classList.add('active'); }
}
navHome.onclick = ()=> showPublicView('home');
navContact.onclick = ()=> showPublicView('contact');
navSignin.onclick = ()=> { showPublicView('signin'); showAuthForm('login'); };
{ const ns = document.getElementById('navStart'); if(ns) ns.onclick = () => { showPublicView('signin'); showAuthForm('signup'); }; }
{ const fc = document.getElementById('faqContact'); if(fc) fc.onclick = () => { showPublicView('contact'); window.scrollTo(0, 0); }; }
document.getElementById('brandHome').onclick = ()=>{ if(!appEntered) showPublicView('home'); };
document.getElementById('landingLogin').onclick = ()=> { showPublicView('signin'); showAuthForm('login'); };
document.getElementById('landingSignup').onclick = ()=> { showPublicView('signin'); showAuthForm('signup'); };
document.getElementById('landingSignup2').onclick = ()=> { showPublicView('signin'); showAuthForm('signup'); };
// Landing page links: section anchors (from any public page), Get started, Contact, Sign in
document.addEventListener('click', (e) => {
  const t = e.target.closest && e.target.closest('[data-goto], [data-start], [data-contact], [data-signin]'); if(!t || (session && session.id)) return;
  if(t.hasAttribute('data-start')){ showPublicView('signin'); showAuthForm('signup'); window.scrollTo(0, 0); return; }
  if(t.hasAttribute('data-contact')){ showPublicView('contact'); window.scrollTo(0, 0); return; }
  if(t.hasAttribute('data-signin')){ showPublicView('signin'); showAuthForm('login'); window.scrollTo(0, 0); return; }
  showPublicView('home');
  const target = document.getElementById(t.dataset.goto);
  if(target) setTimeout(() => target.scrollIntoView({ behavior: 'smooth', block: 'start' }), 30);
});

// ================= auth ui wiring =================
const tabLogin = document.getElementById('tabLogin'), tabSignup = document.getElementById('tabSignup');
const loginForm = document.getElementById('loginForm'), signupForm = document.getElementById('signupForm');
const completeProfileForm = document.getElementById('completeProfileForm');
const authError = document.getElementById('authError');

function showAuthForm(which){
  [loginForm, signupForm, completeProfileForm].forEach(f=>f.classList.add('hidden'));
  tabLogin.classList.remove('active'); tabSignup.classList.remove('active');
  authError.textContent = '';
  if(which === 'login'){ loginForm.classList.remove('hidden'); tabLogin.classList.add('active'); }
  if(which === 'signup'){ signupForm.classList.remove('hidden'); tabSignup.classList.add('active'); }
  if(which === 'complete'){ completeProfileForm.classList.remove('hidden'); }
  const T = { login:['Welcome back', 'Sign in to your shop, your road calls or your fleet.'], signup:['Set up your company', 'Create your account — it takes a few minutes. Mechanics and fleets join with your shop\'s code.'], complete:['Finish setting up', 'A few details and you\'re in.'] }[which];
  const tt = document.getElementById('authTitle'), ts = document.getElementById('authSub');
  if(T && tt){ tt.textContent = T[0]; if(ts) ts.textContent = T[1]; }
}
tabLogin.onclick = ()=> showAuthForm('login');
tabSignup.onclick = ()=> showAuthForm('signup');
{ const toS = document.getElementById('authToSignup'), toL = document.getElementById('authToLogin');
  if(toS) toS.onclick = () => showAuthForm('signup'); if(toL) toL.onclick = () => showAuthForm('login'); }
document.addEventListener('click', (e) => {   // show / hide password
  const b = e.target.closest && e.target.closest('.pw-eye'); if(!b) return;
  const inp = document.getElementById(b.dataset.pw); if(!inp) return;
  const show = inp.type === 'password'; inp.type = show ? 'text' : 'password';
  b.setAttribute('aria-label', show ? 'Hide password' : 'Show password'); b.classList.toggle('on', show);
});

function updateRoleFields(prefix){
  const role = document.getElementById(prefix+'Role').value;
  document.getElementById(prefix+'ShopNameField').classList.toggle('hidden', role !== 'shop');
  document.getElementById(prefix+'InviteField').classList.toggle('hidden', role !== 'mechanic');   // fleets need no code
  document.getElementById(prefix+'CompanyField').classList.toggle('hidden', role !== 'fleet');
}
document.getElementById('suRole').onchange = ()=> updateRoleFields('su');
document.getElementById('cpRole').onchange = ()=> updateRoleFields('cp');
updateRoleFields('su'); updateRoleFields('cp');

// Creates the new person's profile at sign-up. The database checks every case:
//  - shop owner: creates the shop, then becomes its owner (only for a shop they just created)
//  - mechanic: joins through join_shop_as_staff, which checks the invite code and uses it up
//  - fleet manager: signs up with no code and belongs to no shop; they join shops later with a fleet code
async function createSignupProfile(user, f){
  if(f.role === 'shop'){
    if(!f.shopName) return { error: 'Enter your company / shop name.' };
    let orgId = signupCreatedOrg && signupCreatedOrg.name.toLowerCase() === f.shopName.toLowerCase() ? signupCreatedOrg.orgId : null;
    if(!orgId){
      const { data, error } = await sb.from('organizations').insert([{ name: f.shopName }]).select('id');
      if(error || !data || !data[0]) return { error: 'Could not create your company' + (error ? ': ' + friendlyError(error).message : '.') };
      orgId = data[0].id; signupCreatedOrg = { name: f.shopName, orgId };
    }
    const { error } = await sb.from('profiles').insert([{ id: user.id, name: f.name, role: 'shop', org_id: orgId, active: true, email: f.email, phone: f.phone }]);
    return error ? { error: 'Account created, but profile setup failed: ' + friendlyError(error).message } : {};
  }
  if(f.role === 'mechanic'){
    if(!f.inviteCode) return { error: 'Enter the invite code from your shop owner.' };
    const { error } = await sb.rpc('join_shop_as_staff', { p_code: f.inviteCode, p_name: f.name, p_email: f.email, p_phone: f.phone });
    return error ? { error: friendlyError(error).message } : {};
  }
  // fleet manager: no shop, no code
  const { error } = await sb.from('profiles').insert([{ id: user.id, name: f.name, role: 'fleet', company: f.company, org_id: null, active: true, email: f.email, phone: f.phone }]);
  return error ? { error: 'Account created, but profile setup failed: ' + friendlyError(error).message } : {};
}

// resolves { orgId, error } for a signup based on role + shop name / invite code
function generateInviteCode(){
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no ambiguous chars (0/O, 1/I)
  // crypto.getRandomValues is cryptographically secure — Math.random() is not,
  // and invite codes are a security-sensitive token, not just a display string.
  const randomBytes = new Uint8Array(8);
  crypto.getRandomValues(randomBytes);
  return Array.from(randomBytes, b => chars[b % chars.length]).join('');
}
async function rotateInviteCode(orgId){
  await sb.from('organizations').update({ invite_code: generateInviteCode() }).eq('id', orgId);
}

// If profile setup fails after the company was created, clicking the button
// again must not create a second company: reuse the first one this session.
let signupCreatedOrg = null; // { name, orgId }

document.getElementById('signupSubmit').onclick = async (e)=>{
  const btn = e.target; btn.disabled = true;
  const name = document.getElementById('suName').value.trim();
  const email = document.getElementById('suEmail').value.trim();
  const phone = document.getElementById('suPhone').value.trim();
  const role = document.getElementById('suRole').value;
  const shopName = document.getElementById('suShopName').value.trim();
  const inviteCode = document.getElementById('suInvite').value.trim();
  const company = document.getElementById('suCompany').value.trim();
  const pass = document.getElementById('suPass').value;
  authError.textContent = '';
  if(!name || !email || !phone || !pass || (role==='fleet' && !company)){ authError.textContent = 'Fill in all required fields.'; btn.disabled=false; return; }
  if(pass.length < 8){ authError.textContent = 'Password must be at least 8 characters.'; btn.disabled=false; return; }
  if(!sb){ authError.textContent = 'Not connected to the database yet — reload and try again.'; btn.disabled=false; return; }

  const { data, error } = await sb.auth.signUp({ email, password: pass });
  if(error){ authError.textContent = error.message; btn.disabled=false; return; }

  if(data.session && data.user){
    const made = await createSignupProfile(data.user, { role, name, email, phone, shopName, inviteCode, company });
    if(made.error){ authError.textContent = made.error; btn.disabled=false; return; }
    onAuthed(data.session.user.id);
  } else {
    authError.textContent = '';
    relayNotice('Account created! Check your email to confirm it, then log in.', { kind: 'info' });
    showAuthForm('login');
  }
  btn.disabled = false;
};

document.getElementById('loginSubmit').onclick = async (e)=>{
  const btn = e.target; btn.disabled = true;
  const email = document.getElementById('loginEmail').value.trim();
  const pass = document.getElementById('loginPass').value;
  authError.textContent = '';
  if(!sb){ authError.textContent = 'Not connected to the database yet — reload and try again.'; btn.disabled=false; return; }

  const { data, error } = await sb.auth.signInWithPassword({ email, password: pass });
  if(error){ authError.textContent = error.message; btn.disabled=false; return; }
  // Two-step sign-in: if this account uses it, ask for the code before going in.
  if(typeof mfaSignInStep === 'function'){
    const step = await mfaSignInStep();
    if(step && step.needsCode){ showMfaPrompt(step.factorId, data.user.id); btn.disabled = false; return; }
  }
  await onAuthed(data.user.id);
  btn.disabled = false;
};

// Asks for the 6-digit code after the password.
function showMfaPrompt(factorId, userId){
  const card = document.getElementById('loginCard') || document.querySelector('#authView .auth-card');
  const box = document.getElementById('mfaPrompt') || (() => { const d = document.createElement('div'); d.id = 'mfaPrompt'; card.appendChild(d); return d; })();
  document.querySelectorAll('#authView .auth-form').forEach(f => f.classList.add('hidden'));
  box.classList.remove('hidden');
  box.innerHTML = `<h3>One more step</h3><p class="meta">Type the 6-digit number from your authenticator app.</p>
    <div class="field"><label for="mfaLoginCode">Code</label><input id="mfaLoginCode" inputmode="numeric" autocomplete="one-time-code" maxlength="6" class="mono"></div>
    <p class="auth-error" id="mfaLoginErr"></p>
    <button class="auth-submit" id="mfaLoginGo">Sign in</button>
    <button type="button" class="text-btn" id="mfaLoginCancel">Cancel</button>`;
  const input = document.getElementById('mfaLoginCode'); input.focus();
  const go = async () => {
    const b = document.getElementById('mfaLoginGo'); b.disabled = true; b.textContent = 'Checking…';
    const res = await mfaSubmitCode(factorId, input.value);
    b.disabled = false; b.textContent = 'Sign in';
    if(res.error){ document.getElementById('mfaLoginErr').textContent = res.error.message; return; }
    box.classList.add('hidden'); box.innerHTML = '';
    await onAuthed(userId);
  };
  document.getElementById('mfaLoginGo').onclick = go;
  input.addEventListener('keydown', e => { if(e.key === 'Enter') go(); });
  document.getElementById('mfaLoginCancel').onclick = async () => {
    await sb.auth.signOut(); box.classList.add('hidden'); box.innerHTML = '';
    document.querySelectorAll('#authView .auth-form').forEach(f => f.classList.remove('hidden'));
  };
}

document.getElementById('forgotPassBtn').onclick = async ()=>{
  const email = document.getElementById('loginEmail').value.trim();
  if(!email){ authError.textContent = 'Enter your email above first, then tap "Forgot password?" again.'; return; }
  const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });
  authError.textContent = error ? error.message : '';
  if(!error) relayNotice('Password reset email sent — check your inbox (and spam folder).', { kind: 'info' });
};

document.getElementById('completeProfileSubmit').onclick = async (e)=>{
  const btn = e.target; btn.disabled = true;
  const name = document.getElementById('cpName').value.trim();
  const phone = document.getElementById('cpPhone').value.trim();
  const role = document.getElementById('cpRole').value;
  const shopName = document.getElementById('cpShopName').value.trim();
  const inviteCode = document.getElementById('cpInvite').value.trim();
  const company = document.getElementById('cpCompany').value.trim();
  authError.textContent = '';
  if(!name || !phone || (role==='fleet' && !company)){ authError.textContent = 'Fill in all required fields.'; btn.disabled=false; return; }

  const { data: userData, error: getUserErr } = await sb.auth.getUser();
  if(getUserErr || !userData || !userData.user){ authError.textContent = 'Something went wrong confirming your session — please refresh and try again.'; btn.disabled=false; return; }
  const made = await createSignupProfile(userData.user, { role, name, email: userData.user.email, phone, shopName, inviteCode, company });
  if(made.error){ authError.textContent = made.error; btn.disabled=false; return; }
  await onAuthed(userData.user.id);
  btn.disabled = false;
};

// ================= more menu (change password / log out) =================
const moreMenuBtn = document.getElementById('moreMenuBtn');
const moreMenu = document.getElementById('moreMenu');
moreMenuBtn.onclick = (e)=>{
  e.stopPropagation();
  moreMenu.classList.toggle('hidden');
};
document.addEventListener('click', (e)=>{
  if(!moreMenu.classList.contains('hidden') && !moreMenu.contains(e.target) && e.target !== moreMenuBtn){
    moreMenu.classList.add('hidden');
  }
});

const contactModalOverlay = document.getElementById('contactModalOverlay');
document.getElementById('contactUsBtn').onclick = ()=>{
  moreMenu.classList.add('hidden');
  contactModalOverlay.classList.remove('hidden');
};
document.getElementById('contactModalClose').onclick = ()=> contactModalOverlay.classList.add('hidden');
contactModalOverlay.onclick = (e)=>{ if(e.target === contactModalOverlay) contactModalOverlay.classList.add('hidden'); };

document.getElementById('editCompanyBtn').onclick = async ()=>{
  moreMenu.classList.add('hidden');
  const newName = prompt('Enter your new company / shop name:', session.orgName || '');
  if(!newName || !newName.trim()) return;
  const { error } = await sb.from('organizations').update({ name: newName.trim() }).eq('id', session.orgId);
  if(error){ relayFail(error, 'Could not update company name'); return; }
  session.orgName = newName.trim();
  document.getElementById('whoOrg').textContent = session.orgName || '';
  relayNotice('Company name updated.', { kind: 'info' });
};

document.getElementById('changePassBtn').onclick = async ()=>{
  moreMenu.classList.add('hidden');
  const newPass = prompt('Enter a new password (at least 8 characters):');
  if(!newPass) return;
  if(newPass.length < 8){ relayNotice('Password must be at least 8 characters.', { kind: 'info' }); return; }
  const { error } = await sb.auth.updateUser({ password: newPass });
  if(error) relayFail(error, 'Could not change password'); else relayNotice('Password updated.', { kind: 'success' });
};

document.getElementById('logoutBtn').onclick = async ()=>{
  if(watchId !== null){ navigator.geolocation.clearWatch(watchId); watchId = null; }
  if(typeof woDraftClear === 'function') woDraftClear();   // drafts hold customer names: never left on a shared phone
  await sb.auth.signOut();
  location.reload();
};

// ================= auth state =================
async function onAuthed(userId){
  const profile = await fetchMyProfile(userId);
  if(!profile){
    showPublicView('signin');
    showAuthForm('complete');
    return;
  }
  let orgName = null, orgStatus = 'approved';
  if(profile.org_id){
    const { data: orgData } = await sb.from('organizations').select('name, status').eq('id', profile.org_id).maybeSingle();
    orgName = orgData ? orgData.name : null;
    orgStatus = orgData ? orgData.status : 'approved';
  }
  session = { id:profile.id, name:profile.name, role:profile.role, staffRole:profile.staff_role || (profile.role === 'shop' ? 'owner' : profile.role === 'fleet' ? 'fleet_manager' : null), company:profile.company, orgId:profile.org_id, orgName, orgStatus };
  session.locationId = profile.location_id || null;
  if(typeof initHelpExtras === 'function') setTimeout(initHelpExtras, 0);
  if(typeof initHeaderTools === 'function') setTimeout(initHeaderTools, 0);
  if(typeof applyStartupLocation === 'function') applyStartupLocation();   // the right location from the very first request

  if(profile.active === false){
    showInactiveScreen();
    return;
  }
  if(orgStatus !== 'approved'){
    showPendingScreen(orgStatus);
    return;
  }
  enterApp();
}

function showInactiveScreen(){
  document.getElementById('publicNav').classList.add('hidden');
  homeView.classList.add('hidden');
  contactView.classList.add('hidden');
  publicAuthView.classList.add('hidden');
  document.getElementById('whoBox').classList.remove('hidden');
  document.getElementById('whoName').textContent = session.name;
  document.getElementById('whoRole').textContent = 'Inactive';
  document.getElementById('whoOrg').textContent = '';
  document.getElementById('editCompanyBtn').classList.add('hidden');
  document.getElementById('accountInactiveView').classList.remove('hidden');
}

function showPendingScreen(status){
  document.getElementById('publicNav').classList.add('hidden');
  homeView.classList.add('hidden');
  contactView.classList.add('hidden');
  publicAuthView.classList.add('hidden');
  document.getElementById('whoBox').classList.remove('hidden');
  document.getElementById('whoName').textContent = session.name;
  document.getElementById('whoRole').textContent =
    session.role === 'shop' ? ({ owner:'Shop owner', manager:'Manager', dispatcher:'Dispatcher', advisor:'Service advisor' })[session.staffRole] || 'Shop owner' :
    session.role === 'fleet' ? (session.staffRole === 'fleet_user' ? 'Fleet user' : 'Fleet manager') : 'Mechanic';
  document.getElementById('whoOrg').textContent = session.orgName || '';
  document.getElementById('editCompanyBtn').classList.add('hidden');

  const view = document.getElementById('pendingApprovalView');
  view.classList.remove('hidden');
  if(status === 'rejected'){
    document.getElementById('pendingIcon').innerHTML = icon('alert', 40);
    document.getElementById('pendingTitle').textContent = "We couldn't approve this request";
    document.getElementById('pendingBody').textContent = "Your company's request to join Relay wasn't approved. If you think this is a mistake, reach out to us at hello@relayfleet.us.";
    document.getElementById('pendingCheckBtn').classList.add('hidden');
  } else {
    document.getElementById('pendingIcon').innerHTML = icon('clock', 40);
    document.getElementById('pendingTitle').textContent = 'Your request is under review';
    document.getElementById('pendingBody').textContent = "Thanks for signing up for Relay. We're reviewing your company's request and will be in touch shortly.";
    document.getElementById('pendingCheckBtn').classList.remove('hidden');
  }
}

document.getElementById('pendingCheckBtn').onclick = async ()=>{
  const btn = document.getElementById('pendingCheckBtn');
  btn.disabled = true;
  btn.textContent = 'Checking...';
  const { data: orgData } = await sb.from('organizations').select('status').eq('id', session.orgId).maybeSingle();
  const status = orgData ? orgData.status : 'pending';
  if(status === 'approved'){
    document.getElementById('pendingApprovalView').classList.add('hidden');
    enterApp();
  } else {
    session.orgStatus = status;
    showPendingScreen(status);
    btn.disabled = false;
    btn.textContent = 'Check again';
  }
};

// Set the moment a PASSWORD_RECOVERY event fires, and checked by the
// SIGNED_IN branch below too — defense in depth in case a Supabase JS
// version ever fires both events for the same recovery link, so a
// recovery session can never fall through into a normal login before
// the person has actually set a new password.
let inRecoveryFlow = false;

if(sb){
  sb.auth.onAuthStateChange((event, authSession) => {
    if(event === 'PASSWORD_RECOVERY'){
      inRecoveryFlow = true;
      document.getElementById('recoveryModalOverlay').classList.remove('hidden');
      return;
    }
    if(event === 'SIGNED_IN' && authSession && !appEntered && !inRecoveryFlow){
      onAuthed(authSession.user.id);
    }
    if(event === 'SIGNED_OUT'){
      appEntered = false;
    }
  });
  // Wait for the saved session before showing anything, so a refresh goes straight to the
  // person's own screen (no landing or sign-in flash). A timeout guarantees the page never sticks.
  sb.auth.getSession().then(async ({ data }) => {
    if(data.session && !appEntered && !inRecoveryFlow){ try { await onAuthed(data.session.user.id); } catch(_){} }
    bootDone();
  }).catch(bootDone);
  setTimeout(bootDone, 6000);
} else { bootDone(); }
function bootDone(){ document.body.classList.remove('booting'); }

document.getElementById('recoverySubmitBtn').onclick = async ()=>{
  const newPass = document.getElementById('recoveryNewPass').value;
  const confirmPass = document.getElementById('recoveryConfirmPass').value;
  const errEl = document.getElementById('recoveryError');
  errEl.textContent = '';
  if(newPass.length < 8){ errEl.textContent = 'Password must be at least 8 characters.'; return; }
  if(newPass !== confirmPass){ errEl.textContent = 'Passwords do not match.'; return; }

  const btn = document.getElementById('recoverySubmitBtn');
  btn.disabled = true; btn.textContent = 'Saving…';
  const { error } = await sb.auth.updateUser({ password: newPass });
  btn.disabled = false; btn.textContent = 'Set new password';
  if(error){ errEl.textContent = error.message; return; }

  document.getElementById('recoveryModalOverlay').classList.add('hidden');
  inRecoveryFlow = false;
  const { data } = await sb.auth.getSession();
  if(data.session) onAuthed(data.session.user.id);
};

// ================= dashboard tabs / sidebar =================
// The tab bars are rendered as the left sidebar purely through CSS — the
// wiring below is unchanged in spirit (same buttons, same data-targets,
// same panels), it just also keeps the page title in sync and closes the
// mobile drawer after a pick.
function refreshMapSizes(delay){
  // Leaflet maps only learn their real size when told to recalculate —
  // needed after a hidden tab becomes visible, and after the sidebar
  // collapses or expands and changes how wide the content area is.
  setTimeout(()=>{
    [shopMap, pinMapObj, adminOpsMap, mechMapObj].forEach(m=>{ if(m && m.invalidateSize) m.invalidateSize(); });
  }, delay || 50);
}
function tabLabel(tab){
  const label = tab.querySelector('.nav-label');
  return (label ? label.textContent : tab.textContent).trim();
}
function ensurePageTitle(container){
  const view = container.parentElement;
  let header = view.querySelector(':scope > .page-header');
  if(!header){
    header = document.createElement('div');
    header.className = 'page-header';
    header.innerHTML = '<h1 class="page-title"></h1>';
    view.insertBefore(header, view.firstChild);
  }
  return header.querySelector('.page-title');
}
function setNavOpen(open){
  document.body.classList.toggle('nav-open', open);
  const toggle = document.getElementById('navToggle');
  if(toggle && window.matchMedia('(max-width: 900px)').matches) toggle.setAttribute('aria-expanded', String(open));
}
function wireDashTabs(container){
  const tabs = container.querySelectorAll('.dash-tab');
  const panelParent = container.parentElement; // the view div that holds both the tab bar and the panels
  const titleEl = ensurePageTitle(container);
  const initial = container.querySelector('.dash-tab.active') || tabs[0];
  if(initial) titleEl.textContent = tabLabel(initial);
  tabs.forEach(tab=>{
    tab.onclick = ()=>{
      tabs.forEach(t=>{ t.classList.remove('active'); t.removeAttribute('aria-current'); });
      tab.classList.add('active');
      tab.setAttribute('aria-current', 'page');
      titleEl.textContent = tabLabel(tab);
      panelParent.querySelectorAll(':scope > .dash-panel').forEach(p=>p.classList.add('hidden'));
      const target = document.getElementById(tab.dataset.target);
      if(target) target.classList.remove('hidden');
      setNavOpen(false);
      refreshMapSizes();
    };
  });
}
document.querySelectorAll('.dash-tabs').forEach(wireDashTabs);
(function initAppNav(){
  const toggle = document.getElementById('navToggle');
  const backdrop = document.getElementById('navBackdrop');
  if(!toggle) return;
  const mobile = window.matchMedia('(max-width: 900px)');
  let collapsed = false;
  try { collapsed = localStorage.getItem('relay_nav_collapsed') === '1'; } catch(e){}
  document.body.classList.toggle('nav-collapsed', collapsed);
  toggle.setAttribute('aria-expanded', String(mobile.matches ? false : !collapsed));
  toggle.onclick = ()=>{
    if(mobile.matches){ setNavOpen(!document.body.classList.contains('nav-open')); return; }
    const nowCollapsed = document.body.classList.toggle('nav-collapsed');
    toggle.setAttribute('aria-expanded', String(!nowCollapsed));
    try { localStorage.setItem('relay_nav_collapsed', nowCollapsed ? '1' : '0'); } catch(e){}
    refreshMapSizes(220); // wait for the width transition to finish
  };
  if(backdrop) backdrop.onclick = ()=> setNavOpen(false);
  document.addEventListener('keydown', e=>{ if(e.key === 'Escape' && document.body.classList.contains('nav-open')) setNavOpen(false); });
  // Help & support now opens the in-app training guide (training.js); support is inside it.
  document.querySelectorAll('.nav-help').forEach(btn=>{
    btn.onclick = ()=>{ setNavOpen(false); if(typeof openTraining === 'function') openTraining(); };
  });
})();

// ================= app entry =================
// ================= realtime sync =================
// Instead of every dashboard constantly asking "anything new?" every
// few seconds, Supabase pushes changes the instant they happen.
let realtimeChannel = null;
// Live updates arrive in bursts (one change can fire several events). They
// are merged into one refresh, and wait while the tab is hidden.
let rcvTimer = null, rcvPending = false;
function refreshCurrentView(){
  if(!appEntered) return;
  if(document.hidden){ rcvPending = true; return; }
  clearTimeout(rcvTimer);
  rcvTimer = setTimeout(refreshCurrentViewNow, 250);   // a quick pause combines bursts; only changed cards are redrawn
}
document.addEventListener('visibilitychange', () => { if(!document.hidden && rcvPending){ rcvPending = false; refreshCurrentView(); } });
function refreshCurrentViewNow(){
  if(!appEntered) return;
  if(session.role === 'mechanic') renderMechJobs();
  else if(session.role === 'shop') refreshShopData();
  else if(session.role === 'admin') runAdminTabLoad(adminActiveTab());
  else if(session.role === 'fleet') refreshFleetData();
}
// Location pings happen constantly (every few seconds per live mechanic) —
// far too often to justify rebuilding the whole page, since that was wiping
// out anything being typed in an open chat box. Instead we just nudge the
// map marker directly, straight from the realtime payload, touching nothing
// else on the page at all.
function handleLocationPing(payload){
  if(!appEntered) return;
  const row = payload.new;
  if(!row || !row.mechanic_id) return;
  if(session.role === 'shop' && shopMarkers[row.mechanic_id]){
    shopMarkers[row.mechanic_id].setLatLng([row.lat, row.lng]);
  } else if(session.role === 'admin' && adminMarkers[row.mechanic_id]){
    adminMarkers[row.mechanic_id].setLatLng([row.lat, row.lng]);
  } else if(session.role === 'fleet'){
    const jobIds = fleetJobsByMechanic[row.mechanic_id] || [];
    jobIds.forEach(jobId=>{
      const entry = fleetMaps[jobId];
      if(!entry) return;
      if(entry.mechMarker) entry.mechMarker.setLatLng([row.lat, row.lng]);
      else entry.mechMarker = L.marker([row.lat, row.lng], { icon: pinIcon('mech') }).addTo(entry.map);
    });
  }
  // Mechanic's own marker is already handled locally by their own GPS callback.
}
function setupRealtimeSync(){
  if(realtimeChannel || !sb) return;
  realtimeChannel = sb.channel('relay-live-updates')
    .on('postgres_changes', Object.assign({ event: '*', schema: 'public', table: 'jobs' },
        // Only this shop's jobs (or this fleet's) — not every change in the system.
        session.role === 'fleet' ? { filter: 'fleet_profile_id=eq.' + session.id }
        : session.orgId ? { filter: 'org_id=eq.' + session.orgId } : {}), refreshCurrentView);
  // Mechanic positions (audit fix, 0028): shop staff and mechanics get only their own shop's;
  // the platform admin gets all; fleets get their joined shops' (below) — never the whole platform.
  // Service requests: the owner's Requests list and count update the moment a request arrives,
  // with a short notice — no page refresh needed.
  if(session.role === 'shop' && session.orgId){
    const onRequestChange = () => {
      refreshRequestCount();
      const panel = document.getElementById('shop-requests');
      if(panel && !panel.classList.contains('hidden') && typeof refreshWorkRequests === 'function') refreshWorkRequests();
    };
    realtimeChannel.on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'work_requests', filter: 'org_id=eq.' + session.orgId }, (payload) => {
      onRequestChange();
      const who = payload && payload.new ? (payload.new.company_name || payload.new.customer_name || 'a customer') : 'a customer';
      if(typeof recordsToast === 'function') recordsToast('New service request from ' + who);
    });
    realtimeChannel.on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'work_requests', filter: 'org_id=eq.' + session.orgId }, onRequestChange);
  }
  if(session.role === 'admin') realtimeChannel.on('postgres_changes', { event: '*', schema: 'public', table: 'locations' }, handleLocationPing);
  else if(session.role !== 'fleet' && session.orgId) realtimeChannel.on('postgres_changes', { event: '*', schema: 'public', table: 'locations', filter: 'org_id=eq.' + session.orgId }, handleLocationPing);
  if(typeof addLiveTables === 'function') realtimeChannel = addLiveTables(realtimeChannel);   // estimates, payments, appointments, messages (live.js)
  realtimeChannel.subscribe();
  // safety net: the request count is re-checked each minute while the app is open
  if(session.role === 'shop' && typeof everyWhileVisible === 'function') everyWhileVisible(() => { if(typeof refreshRequestCount === 'function') refreshRequestCount(); }, 60000);
  // Fleets: mechanics of the shops they've joined (looked up once).
  if(session.role === 'fleet'){
    sb.from('fleet_shop_links').select('org_id').eq('fleet_id', session.id).then(({ data }) => {
      const ids = (data || []).map(r => r.org_id).filter(Boolean);
      if(!ids.length || fleetLocChannel) return;
      fleetLocChannel = sb.channel('relay-fleet-locations')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'locations', filter: 'org_id=in.(' + ids.slice(0, 100).join(',') + ')' }, handleLocationPing)
        .subscribe();
    });
  }
}
let fleetLocChannel = null;

function enterApp(){
  if(appEntered) return;
  appEntered = true;
  if(typeof relayLangInit === 'function') relayLangInit();   // language picker for shop staff and mechanics
  if(typeof initExportUI === 'function') initExportUI();
  if(typeof renderRemovedBox === 'function') renderRemovedBox();
  if(typeof renderOverdueBox === 'function') renderOverdueBox();
  if(typeof initFeedbackUI === 'function') initFeedbackUI();
  if(typeof renderMfaBox === 'function') renderMfaBox();
  document.getElementById('publicNav').classList.add('hidden');
  homeView.classList.add('hidden');
  contactView.classList.add('hidden');
  publicAuthView.classList.add('hidden');
  document.getElementById('whoBox').classList.remove('hidden');
  document.getElementById('whoName').textContent = session.name;
  document.getElementById('whoRole').textContent =
    session.role === 'admin' ? 'Admin' :
    session.role === 'shop' ? ({ owner:'Shop owner', manager:'Manager', dispatcher:'Dispatcher', advisor:'Service advisor' })[session.staffRole] || 'Shop owner' :
    session.role === 'fleet' ? (session.staffRole === 'fleet_user' ? 'Fleet user' : 'Fleet manager') : 'Mechanic';
  document.getElementById('whoOrg').textContent = session.orgName || '';
  document.getElementById('editCompanyBtn').classList.toggle('hidden', session.role !== 'shop');

  document.body.classList.add('in-app');
  if(session.role === 'shop' || session.role === 'admin' || session.role === 'fleet'){   // fleet portal uses the same left menu
    document.body.classList.add('has-sidebar');
    document.getElementById('navToggle').classList.remove('hidden');
  }

  if(typeof prepareRoute === 'function') prepareRoute();   // the saved section is set before the screen is drawn
  if(session.role === 'mechanic'){ document.getElementById('mechanicView').classList.remove('hidden'); initMechanicView(); }
  else if(session.role === 'shop'){ document.getElementById('shopView').classList.remove('hidden'); initShopView(); if(typeof checkShopSetupGate === 'function') checkShopSetupGate(); if(typeof maybeStartTour === 'function') maybeStartTour(); }
  else if(session.role === 'admin'){ document.getElementById('adminView').classList.remove('hidden'); initAdminView(); if(typeof watchDemoRequests === 'function') watchDemoRequests(); if(typeof renderDemoRequests === 'function') renderDemoRequests(); }
  else { document.getElementById('fleetView').classList.remove('hidden'); initFleetView(); }
  // a refresh comes back to the same screen, section and work order (route.js)
  if(typeof restoreRoute === 'function') restoreRoute();


  setupRealtimeSync();

  // Watch for admin deactivating this account WHILE they're using the app —
  // kicks them out immediately instead of waiting for their next reload.
  everyWhileVisible(async ()=>{
    const { data } = await sb.from('profiles').select('active').eq('id', session.id).maybeSingle();
    if(data && data.active === false){
      if(watchId !== null){ navigator.geolocation.clearWatch(watchId); watchId = null; }
      document.getElementById('mechanicView').classList.add('hidden');
      document.getElementById('shopView').classList.add('hidden');
      document.getElementById('adminView').classList.add('hidden');
      document.getElementById('fleetView').classList.add('hidden');
      document.body.classList.remove('has-sidebar', 'nav-open');
      document.getElementById('navToggle').classList.add('hidden');
      showInactiveScreen();
    }
  }, 60000);
}

// ================= MECHANIC VIEW =================
function initMechanicView(){
  if(mechMapObj){ mechMapObj.remove(); mechMapObj = null; } // this view's init can run more than once per page session — a fresh L.map() on an already-initialized container throws
  mechMapObj = L.map('mechMap', { zoomControl:true, attributionControl:false }).setView([42.45, -83.25], 10);
  addBaseMapToggle(mechMapObj);

  document.getElementById('mechStatus').onchange = async (e)=>{
    await updateLocationStatus(session.id, e.target.value);
    renderMechJobs();
  };

  const goLiveBtn = document.getElementById('goLiveBtn');
  goLiveBtn.onclick = ()=>{ if(watchId === null) startTracking(); else stopTracking(); };

  function startTracking(){
    if(!navigator.geolocation){ document.getElementById('gpsReadout').textContent = 'Geolocation is not available in this browser.'; return; }
    goLiveBtn.textContent = 'Go offline';
    goLiveBtn.classList.remove('offline-state');
    document.getElementById('liveBadge').className = 'badge live';
    document.getElementById('liveBadge').innerHTML = '<span class="bd"></span>Live';

    let lastWrite = 0;
    watchId = navigator.geolocation.watchPosition(async (pos)=>{
      const { latitude, longitude, accuracy } = pos.coords;
      document.getElementById('gpsReadout').innerHTML =
        `Lat <b>${latitude.toFixed(5)}</b> · Lng <b>${longitude.toFixed(5)}</b> · Accuracy <b>±${Math.round(accuracy)}m</b> · Updated <b>${new Date().toLocaleTimeString()}</b>`;

      if(!mechMarker){
        mechMarker = L.marker([latitude, longitude], { icon: pinIcon('mech') }).addTo(mechMapObj);
        mechMapObj.setView([latitude, longitude], 13);
      } else {
        mechMarker.setLatLng([latitude, longitude]);
      }

      const now = Date.now();
      if(now - lastWrite > 4000){
        lastWrite = now;
        await upsertLocation(session.id, latitude, longitude, document.getElementById('mechStatus').value);
      }
      // Update just the distance numbers directly instead of rebuilding the
      // whole page — this used to call renderMechJobs() on every single GPS
      // tick (often every 1-3 seconds), which was wiping out anything being
      // typed in an open chat box. Distances still update live; nothing else
      // needs to change just because the GPS pinged.
      mechActiveJobsCache.forEach(job=>{
        if(job.job_type === 'inshop') return; // no destination to measure distance to
        const el = document.getElementById('mech-dist-'+job.id);
        if(!el) return;
        const mi = milesBetween(latitude, longitude, job.dest_lat, job.dest_lng);
        el.textContent = mi < 0.1 ? 'Arrived' : mi.toFixed(1) + ' mi away';
      });
    }, (err)=>{
      document.getElementById('gpsReadout').textContent = 'Location error: ' + err.message + '. Check that location access is allowed for this page.';
    }, { enableHighAccuracy:true, maximumAge:5000, timeout:15000 });
  }

  function stopTracking(){
    if(watchId !== null){ navigator.geolocation.clearWatch(watchId); watchId = null; }
    // Mark the saved position as not live, so fleet customers stop seeing it
    // right away (the database also hides positions older than 10 minutes,
    // which covers a phone that closes the tab without pressing Go offline).
    sb.from('locations').update({ is_live:false }).eq('mechanic_id', session.id)
      .then(({ error }) => { if(error) console.error('mark offline', error); });
    goLiveBtn.textContent = 'Go live';
    goLiveBtn.classList.add('offline-state');
    document.getElementById('liveBadge').className = 'badge offline';
    document.getElementById('liveBadge').innerHTML = '<span class="bd"></span>Offline';
    document.getElementById('gpsReadout').textContent = 'Location sharing stopped.';
  }

  renderMechJobs();
  everyWhileVisible(renderMechJobs, 120000); // fallback only - Realtime handles instant updates
  if(typeof initWorkUI === 'function') initWorkUI();
  if(typeof initClockUI === 'function') initClockUI();
  if(typeof initNotifications === 'function') initNotifications();
}

async function renderMechJobs(){
  let active = await fetchActiveJobs({ mechanicId: session.id });
  // Jobs where this mechanic was added as a technician (Redesign R4a).
  if(typeof fetchHelperJobs === 'function'){ const extra = await fetchHelperJobs(); active = active.concat(extra.filter(x => !active.some(a => a.id === x.id))); }
  const history = await fetchCompletedJobs(15, { mechanicId: session.id });
  mechActiveJobsCache = active; // used by the GPS ticker to update distance without a full rebuild

  document.getElementById('mechActiveCount').textContent = active.length ? active.length + ' active' : '';

  const loc = await fetchLocation(session.id);

  const activeBox = document.getElementById('mechJobsBox');
  const _s1 = preserveOpenChatNodes(activeBox);
  if(active.length === 0){
    activeBox.innerHTML = '<div class="empty-note">No jobs assigned right now.</div>';
  } else {
    activeBox.innerHTML = active.map(job => {
      const isInshop = job.job_type === 'inshop';
      let distText = '—';
      if(!isInshop && loc){
        const mi = milesBetween(loc.lat, loc.lng, job.dest_lat, job.dest_lng);
        distText = mi < 0.1 ? 'Arrived' : mi.toFixed(1) + ' mi away';
        if(!mechDestMarkers[job.id]) mechDestMarkers[job.id] = L.marker([job.dest_lat, job.dest_lng], { icon: pinIcon('dest') }).addTo(mechMapObj);
      }
      const distRow = isInshop ? '' : `<div class="row"><span>Distance</span><b id="mech-dist-${job.id}">${distText}</b></div>`;
      const directionsBtn = isInshop ? '' : `<a class="directions-btn" href="https://www.google.com/maps/dir/?api=1&destination=${job.dest_lat},${job.dest_lng}" target="_blank" rel="noopener">${icon('compass')} Get directions</a>`;
      // In-shop jobs skip "heading there" entirely — there's no travel,
      // so the job goes straight from assigned to being worked on.
      // One big button opens the Work screen, which runs the timers and
      // moves the job through its statuses (Phase 4, tech.js).
      // Until the job is accepted, Accept is the main button and Work steps back.
      const awaiting = !job.accepted_at && !job.declined_at && ['new','assigned'].includes(job.status);
      const actionButtons = `<button type="button" class="j-work work-launch${awaiting ? ' work-launch-quiet' : ''}" data-job="${job.id}">▶ Work on this job</button>`;
      return `
        <div class="job-card" data-job="${job.id}">
          <div class="job-card-top">
            <div>${isInshop ? '<span class="doc-kind-tag">IN-SHOP</span>' : ''}<b>${esc(job.customer)}</b><div class="meta">${esc(job.vehicle)}</div></div>
          </div>
          ${roChipsHtml(job)}
          ${job.complaint ? `<div class="ro-complaint">${esc(job.complaint)}</div>` : ''}
          ${distRow}
          <div class="row"><span>Status</span><b>${esc(statusLabel(job.status))}</b></div>
          ${directionsBtn}
          ${typeof acceptBlockHtml === 'function' ? acceptBlockHtml(job) : ''}
          <div class="job-actions">
            ${actionButtons}
            <button class="j-open-ro" data-job="${job.id}">Open work order</button>
          </div>
          ${commentsBlockHtml(job.id)}
          ${attachmentsBlockHtml(job.id)}
        </div>`;
    }).join('');

    wireCommentToggles(activeBox);
    wireAttachmentToggles(activeBox);
    activeBox.querySelectorAll('.job-card').forEach(card=>{
      const jobId = Number(card.dataset.job);
      const job = active.find(j=>j.id===jobId);
      card.querySelectorAll('.job-actions button[data-s]').forEach(btn=>{
        btn.onclick = async ()=>{
          const { error } = await sb.from('jobs').update({ status: btn.dataset.s, updated_at: new Date().toISOString() }).eq('id', jobId);
          if(error){ relayFail(error.message); return; }
          if(!error){
            if(btn.dataset.s === 'complete') showCompleteToast(job);
            renderMechJobs();
          }
        };
      });
    });
  }
  restoreOpenChatNodes(activeBox, _s1);

  const historyBox = document.getElementById('mechHistoryBox');
  const _s2 = preserveOpenChatNodes(historyBox);
  historyBox.innerHTML = history.length === 0
    ? '<div class="empty-note">No completed jobs yet.</div>'
    : history.map(job => `
        <div class="job-card">
          <div class="job-card-top"><div><b>${esc(job.customer)}</b><div class="meta">${esc(job.vehicle)}</div></div>${jobStatusBadge(job.status)}</div>
          ${commentsBlockHtml(job.id)}
          ${attachmentsBlockHtml(job.id)}
        </div>`).join('');
  wireCommentToggles(historyBox);
  wireAttachmentToggles(historyBox);
  restoreOpenChatNodes(historyBox, _s2);
}

// ================= SHOP OWNER VIEW =================
let shopMap = null, pinMapObj = null, pinMarker = null, chosenPin = null;
const shopMarkers = {};

async function loadInviteCode(){
  const box = document.getElementById('inviteCodeBox');
  if(!box || !session.orgId) return;
  const { data, error } = await sb.from('organizations').select('invite_code, name').eq('id', session.orgId).maybeSingle();
  if(error || !data){ box.innerHTML = '<div class="empty-note">Could not load invite code.</div>'; return; }
  box.innerHTML = `<span class="code">${esc(data.invite_code)}</span><button id="copyInviteBtn">Copy</button>`;
  document.getElementById('copyInviteBtn').onclick = ()=>{
    navigator.clipboard.writeText(data.invite_code);
    const b = document.getElementById('copyInviteBtn');
    b.textContent = 'Copied!'; setTimeout(()=>{ b.textContent = 'Copy'; }, 1500);
  };
}

document.getElementById('regenerateInviteBtn').onclick = async ()=>{
  if(!session || !session.orgId) return;
  if(!(await relayConfirm({ message: 'This will make the current invite code stop working immediately. Continue?' }))) return;
  await rotateInviteCode(session.orgId);
  loadInviteCode();
};

// ================= invoices UI =================
let invItemRowCounter = 0;

function addInvoiceItemRow(prefill){
  const container = document.getElementById('invItemRows');
  if(!container) return;
  const row = document.createElement('div');
  row.className = 'inv-item-row';
  row.id = 'invRow' + (invItemRowCounter++);
  row.innerHTML = `
    <input type="text" placeholder="Description" class="inv-desc" value="${esc(prefill && prefill.description || '')}">
    <input type="number" placeholder="Qty" class="inv-qty" min="0.01" step="0.01" value="${prefill && prefill.quantity != null ? prefill.quantity : 1}">
    <input type="number" placeholder="Price" class="inv-price" min="0" step="0.01" value="${prefill && prefill.unit_price != null ? prefill.unit_price : ''}">
    <button type="button" class="inv-item-remove" title="Remove line">×</button>
  `;
  row.querySelector('.inv-item-remove').onclick = ()=>{ row.remove(); recalcInvoiceTotal(); };
  row.querySelectorAll('.inv-qty, .inv-price').forEach(inp => inp.addEventListener('input', recalcInvoiceTotal));
  container.appendChild(row);
  recalcInvoiceTotal();
}

function collectInvoiceItemRows(){
  const rows = document.querySelectorAll('#invItemRows .inv-item-row');
  const items = [];
  rows.forEach((row, i)=>{
    const description = row.querySelector('.inv-desc').value.trim();
    const quantity = parseFloat(row.querySelector('.inv-qty').value);
    const unit_price = parseFloat(row.querySelector('.inv-price').value);
    if(description && quantity > 0 && unit_price >= 0){
      items.push({ description, quantity, unit_price, sort_order: i });
    }
  });
  return items;
}

function recalcInvoiceTotal(){
  const total = collectInvoiceItemRows().reduce((sum, it)=> sum + it.quantity * it.unit_price, 0);
  const el = document.getElementById('invTotalDisplay');
  if(el) el.textContent = '$' + total.toFixed(2);
}

let selectedInvoiceKind = 'invoice';
let cachedReviewLink = null;

function resetInvoiceForm(){
  document.getElementById('invCustomerName').value = '';
  document.getElementById('invCustomerAddress').value = '';
  document.getElementById('invUnitNumber').value = '';
  document.getElementById('invJobSelect').value = '';
  document.getElementById('invNotes').value = '';
  document.getElementById('invItemRows').innerHTML = '';
  addInvoiceItemRow();
}

function setInvoiceFormKind(kind){
  selectedInvoiceKind = kind;
  document.getElementById('kindInvoiceBtn').classList.toggle('active', kind === 'invoice');
  document.getElementById('kindEstimateBtn').classList.toggle('active', kind === 'estimate');
  document.getElementById('invFormTitle').textContent = kind === 'estimate' ? 'New estimate' : 'New invoice';
  document.getElementById('createInvoiceBtn').textContent = kind === 'estimate' ? 'Save estimate' : 'Save invoice';
}

async function populateInvoiceJobSelect(){
  const sel = document.getElementById('invJobSelect');
  if(!sel) return;
  const jobs = await fetchJobsForInvoiceLink();
  sel.innerHTML = '<option value="">— No linked job —</option>' +
    jobs.map(j => `<option value="${j.id}">#${j.id} — ${esc(j.customer)} (${esc(j.vehicle)})</option>`).join('');
}

async function createInvoice(){
  const customerName = document.getElementById('invCustomerName').value.trim();
  const customerAddress = document.getElementById('invCustomerAddress').value.trim();
  const unitNumber = document.getElementById('invUnitNumber').value.trim();
  const jobId = document.getElementById('invJobSelect').value;
  const notes = document.getElementById('invNotes').value.trim();
  const items = collectInvoiceItemRows();
  const kind = selectedInvoiceKind;
  if(!customerName){ relayNotice('Enter a customer name.', { kind: 'info' }); return; }
  if(!items.length){ relayNotice('Add at least one line item with a description, quantity, and price.', { kind: 'info' }); return; }

  const btn = document.getElementById('createInvoiceBtn');
  btn.disabled = true; btn.textContent = 'Saving…';

  const { data: invoice, error } = await sb.from('invoices').insert([{
    org_id: session.orgId,
    job_id: jobId ? Number(jobId) : null,
    kind,
    customer_name: customerName,
    customer_address: customerAddress || null,
    unit_number: unitNumber || null,
    notes: notes || null,
    status: 'draft',
    created_by: session.id,
  }]).select().single();

  if(error){
    relayFail(error, `Could not create ${kind}`);
    btn.disabled = false; setInvoiceFormKind(kind);
    return;
  }

  const itemRows = items.map(it => ({ invoice_id: invoice.id, description: it.description, quantity: it.quantity, unit_price: it.unit_price, sort_order: it.sort_order }));
  const { error: itemErr } = await sb.from('invoice_items').insert(itemRows);
  if(itemErr) relayFail(itemErr, `${kind === 'estimate' ? 'Estimate' : 'Invoice'} was created, but its line items did not save`);

  resetInvoiceForm();
  if(typeof docNewClose === 'function') docNewClose();   // the form lives in a sheet now
  btn.disabled = false; setInvoiceFormKind(kind);
  refreshInvoices();
}

async function sendInvoiceEmail(invoiceId, email){
  if(!email || !email.includes('@')){ relayNotice('Enter a valid email address first.', { kind: 'info' }); return; }
  const { data, error } = await sb.functions.invoke('send-invoice-email', { body: { invoiceId, recipientEmail: email } });
  if(error){ relayFail(error, 'Could not send'); return; }
  if(data && data.error){ relayFail(data.error, 'Could not send'); return; }
  refreshInvoices();
}

async function markInvoicePaid(invoiceId){
  const { error } = await sb.from('invoices').update({ status:'paid', paid_at:new Date().toISOString() }).eq('id', invoiceId);
  if(error){ relayFail(error, 'Could not update'); return; }
  if(typeof notifyKick === 'function') notifyKick();   // send the paid receipt now instead of waiting for the schedule
  refreshInvoices();
}

async function updateEstimateStatus(invoiceId, newStatus){
  const { error } = await sb.from('invoices').update({ status:newStatus }).eq('id', invoiceId);
  if(error){ relayFail(error, 'Could not update'); return; }
  refreshInvoices();
}

// Copies an approved (or declined — the customer may still change their
// mind) estimate's line items into a brand-new invoice, linked back via
// source_estimate_id, and marks the estimate itself as converted so it
// can't be converted twice.
async function convertEstimateToInvoice(estimateId){
  if(!(await relayConfirm({ message: 'Convert this estimate into an invoice? Lines the customer declined are left out.' }))) return;
  const { data, error } = await sb.rpc('convert_estimate_to_invoice', { p_estimate: estimateId });
  if(error){ relayFail(error, 'Could not create the invoice'); return; }
  refreshInvoices();
  if(typeof openEstimateEditor === 'function') openEstimateEditor(Number(data));
}

async function sendReviewRequest(invoiceId, email){
  if(!email || !email.includes('@')){ relayNotice('Enter a valid email address first.', { kind: 'info' }); return; }
  // Phase 9: invoices on a repair order use the tracked review flow (one per job, opens recorded).
  const { data: inv } = await sb.from('invoices').select('doc_number, job_id').eq('id', invoiceId).maybeSingle();
  if(inv && inv.job_id){
    let { error } = await sb.rpc('request_review', { p_job: inv.job_id, p_email: email, p_resend: false });
    if(error && /already/.test(error.message) && await relayConfirm({ message: 'A review was already requested for this job. Send another?', confirmText: 'Send another' })){
      ({ error } = await sb.rpc('request_review', { p_job: inv.job_id, p_email: email, p_resend: true }));
    } else if(error && /already/.test(error.message)) return;
    if(error){ relayFail(error, 'Could not send the review request'); return; }
    if(typeof notifyKick === 'function') notifyKick();
    relayNotice('Review request sent.', { kind: 'info' });
    return;
  }
  const { data, error } = await sb.functions.invoke('send-review-request', { body: { invoiceId, recipientEmail: email } });
  if(error){ relayFail(error, 'Could not send the review request'); return; }
  if(data && data.error){ relayFail(data.error, 'Could not send the review request'); return; }
  relayNotice('Review request sent.', { kind: 'info' });
}

async function deleteInvoiceDraft(invoiceId){
  if(!(await relayConfirm({ message: 'Delete this draft? This cannot be undone.' }))) return;
  const { error } = await sb.from('invoices').delete().eq('id', invoiceId);
  if(error){ relayFail(error, 'Could not delete'); return; }
  refreshInvoices();
}

function invoiceStatusBadge(status){
  if(status === 'paid' || status === 'approved') return `<span class="badge arrived"><span class="bd"></span>${status}</span>`;
  if(status === 'unpaid' || status === 'sent') return `<span class="badge live"><span class="bd"></span>${status}</span>`;
  if(status === 'declined') return '<span class="badge offline"><span class="bd"></span>declined</span>';
  if(status === 'converted') return '<span class="badge offline"><span class="bd"></span>converted</span>';
  return '<span class="badge offline"><span class="bd"></span>draft</span>';
}

function invoiceCardHtml(inv){
  const isEstimate = inv.kind === 'estimate';
  const items = inv.invoice_items || [];
  const total = inv.total != null ? Number(inv.total) : items.reduce((sum, it)=> sum + Number(it.quantity) * Number(it.unit_price), 0);
  const itemsHtml = items.map(it => `<div class="meta">${esc(it.description)} — ${it.quantity} × $${Number(it.unit_price).toFixed(2)}</div>`).join('');
  const jobTag = inv.job_id ? `<div class="meta">Linked to job #${inv.job_id}</div>` : '';
  const unitTag = inv.unit_number ? `<div class="meta">Unit #${esc(inv.unit_number)}</div>` : '';
  const kindTag = `<span class="doc-kind-tag">${isEstimate ? 'ESTIMATE' : 'INVOICE'}</span>`;

  let actions = `<button class="text-btn inv-open-editor" data-doc="${inv.id}">Open</button><button class="text-btn inv-view-btn" data-id="${inv.id}">View PDF</button>`;
  if(inv.status === 'draft') actions += `<button class="text-btn inv-delete-btn" data-id="${inv.id}">Delete draft</button>`;
  else if(!isEstimate && inv.status === 'unpaid') actions += `<button class="text-btn inv-paid-btn" data-id="${inv.id}">Mark paid</button>`;
  else if(isEstimate && inv.status === 'sent'){
    actions += `<button class="text-btn inv-approve-btn" data-id="${inv.id}">Mark approved</button>`;
    actions += `<button class="text-btn inv-decline-btn" data-id="${inv.id}">Mark declined</button>`;
  } else if(isEstimate && (inv.status === 'approved' || inv.status === 'declined')){
    actions += `<button class="text-btn inv-convert-btn" data-id="${inv.id}">Convert to invoice</button>`;
  }
  if(!isEstimate && inv.status === 'paid' && cachedReviewLink){
    actions += `<button class="text-btn inv-review-btn" data-id="${inv.id}">Send review request</button>`;
  }

  // Estimates are sent from the editor (Open), which creates the customer's approval link.
  const canSend = !isEstimate && (inv.status === 'draft' || inv.status === 'unpaid');
  const sendRow = canSend ? `
    <div class="invoice-send-row">
      <input type="email" class="inv-send-email" placeholder="customer@email.com" value="${esc(inv.customer_email || '')}" data-id="${inv.id}">
      <button class="text-btn inv-send-btn" data-id="${inv.id}">${inv.sent_at ? 'Resend' : (isEstimate ? 'Send for approval' : 'Send')}</button>
    </div>` : '';
  const reviewSendRow = (!isEstimate && inv.status === 'paid' && cachedReviewLink) ? `
    <div class="invoice-send-row">
      <input type="email" class="inv-review-email" placeholder="customer@email.com" value="${esc(inv.customer_email || '')}" data-id="${inv.id}">
    </div>` : '';

  return `<div class="job-card">
    <div class="job-card-top"><div>${kindTag}<b>${esc(inv.customer_name)}</b><div class="meta">$${total.toFixed(2)} · ${new Date(inv.created_at).toLocaleDateString()}</div></div>${invoiceStatusBadge(inv.status)}</div>
    ${unitTag}
    ${jobTag}
    ${itemsHtml}
    ${inv.notes ? `<div class="meta">${esc(inv.notes)}</div>` : ''}
    ${inv.approved_by_name && inv.status === 'approved' ? `<div class="meta">Approved by ${esc(inv.approved_by_name)}</div>` : ''}
    ${inv.po_number ? `<div class="meta">PO ${esc(inv.po_number)}</div>` : ''}
    <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;">${actions}</div>
    ${sendRow}
    ${reviewSendRow}
  </div>`;
}

// Opens the PDF in a sheet inside the app (pdfview.js) — works in the iPhone Home Screen app too.
async function viewInvoicePdf(invoiceId){
  if(typeof viewInvoicePdfInApp === 'function') return viewInvoicePdfInApp(invoiceId);
}

async function refreshInvoices(){
  if(typeof refreshDocsTable === 'function') return refreshDocsTable('quiet');   // the new table (docs.js); background refreshes keep your place
  const list = document.getElementById('invoiceList');
  if(!list) return;
  const invoices = await fetchInvoices();
  if(invoices.loadError){
    list.innerHTML = `<div class="auth-banner wait"><b>Invoices couldn't be loaded.</b> ${esc(invoices.loadError)}${/doc_number/.test(invoices.loadError) ? '<br>The database is missing an update: run migration 0023_doc_numbers.sql (then 0024 and 0025) in Supabase, then refresh.' : ''}</div>`;
    return;
  }
  list.innerHTML = (invoices.length ? invoices.map(invoiceCardHtml).join('') : '<div class="empty-note">No invoices or estimates yet.</div>')
    + (invoices.length >= invoiceLimit ? '<div class="load-more-row"><button type="button" class="ghost-btn" id="invLoadMore">Load older</button></div>' : '');
  const more = document.getElementById('invLoadMore');
  if(more) more.onclick = () => { invoiceLimit += 100; refreshInvoices(); };

  list.querySelectorAll('.inv-view-btn').forEach(btn=>{ btn.onclick = ()=> viewInvoicePdf(Number(btn.dataset.id)); });
  list.querySelectorAll('.inv-delete-btn').forEach(btn=>{ btn.onclick = ()=> deleteInvoiceDraft(Number(btn.dataset.id)); });
  list.querySelectorAll('.inv-paid-btn').forEach(btn=>{ btn.onclick = ()=> markInvoicePaid(Number(btn.dataset.id)); });
  list.querySelectorAll('.inv-approve-btn').forEach(btn=>{ btn.onclick = ()=> updateEstimateStatus(Number(btn.dataset.id), 'approved'); });
  list.querySelectorAll('.inv-decline-btn').forEach(btn=>{ btn.onclick = ()=> updateEstimateStatus(Number(btn.dataset.id), 'declined'); });
  list.querySelectorAll('.inv-convert-btn').forEach(btn=>{ btn.onclick = ()=> convertEstimateToInvoice(Number(btn.dataset.id)); });
  list.querySelectorAll('.inv-send-btn').forEach(btn=>{
    btn.onclick = ()=>{
      const id = Number(btn.dataset.id);
      const input = list.querySelector(`.inv-send-email[data-id="${id}"]`);
      sendInvoiceEmail(id, input.value.trim());
    };
  });
  list.querySelectorAll('.inv-review-btn').forEach(btn=>{
    btn.onclick = ()=>{
      const id = Number(btn.dataset.id);
      const input = list.querySelector(`.inv-review-email[data-id="${id}"]`);
      sendReviewRequest(id, input ? input.value.trim() : '');
    };
  });
}

function initInvoicesUI(){
  populateInvoiceJobSelect();
  addInvoiceItemRow();
  fetchBillingProfile().then(profile => { cachedReviewLink = profile && profile.review_link ? profile.review_link : null; refreshInvoices(); });
  refreshInvoices();
  everyWhileVisible(() => { if(panelVisible('shop-invoices')) refreshInvoices(); }, 120000);   // only while the Invoices page is open
  document.getElementById('addInvItemBtn').onclick = ()=> addInvoiceItemRow();
  const invItemPicker = document.getElementById('invItemPicker');
  invItemPicker.onchange = ()=>{
    const opt = invItemPicker.selectedOptions[0];
    if(!opt || !opt.value) return;
    addInvoiceItemRow({ description: opt.dataset.name, unit_price: opt.dataset.price });
    invItemPicker.value = '';
  };
  populateInventoryPicker();
  document.getElementById('createInvoiceBtn').onclick = createInvoice;
  document.getElementById('kindInvoiceBtn').onclick = ()=> setInvoiceFormKind('invoice');
  document.getElementById('kindEstimateBtn').onclick = ()=> setInvoiceFormKind('estimate');
}

// ================= billing profile UI =================
async function fetchBillingProfile(){
  const { data, error } = await sb.from('organizations')
    .select('name, billing_email, billing_phone, billing_address, payment_instructions, logo_path, review_link, default_tax_rate, labor_rate, invoice_terms')
    .eq('id', session.orgId).single();
  if(error){ console.error('fetchBillingProfile', error); return null; }
  return data;
}

function billingLogoPublicUrl(logoPath){
  if(!logoPath) return '';
  const { data } = sb.storage.from('shop-logos').getPublicUrl(logoPath);
  return data ? data.publicUrl : '';
}

async function populateBillingForm(){
  const profile = await fetchBillingProfile();
  if(!profile) return;
  document.getElementById('billingEmail').value = profile.billing_email || '';
  document.getElementById('billingPhone').value = profile.billing_phone || '';
  document.getElementById('billingAddress').value = profile.billing_address || '';
  document.getElementById('billingPaymentInstructions').value = profile.payment_instructions || '';
  { const it = document.getElementById('billingInvoiceTerms'); if(it) it.value = profile.invoice_terms || ''; }
  document.getElementById('billingReviewLink').value = profile.review_link || '';
  const tr = document.getElementById('billingTaxRate'); if(tr) tr.value = profile.default_tax_rate != null ? Number(profile.default_tax_rate) : '';
  const lr = document.getElementById('billingLaborRate'); if(lr) lr.value = profile.labor_rate != null ? Number(profile.labor_rate) : '';
  const preview = document.getElementById('billingLogoPreview');
  if(profile.logo_path){
    preview.src = billingLogoPublicUrl(profile.logo_path);
    preview.style.display = 'block';
  } else {
    preview.style.display = 'none';
  }
}

// Default tax rate (%) and labor rate ($/hour) used when starting estimates.
function billingRatesUpdate(){
  const out = {};
  const tr = document.getElementById('billingTaxRate'), lr = document.getElementById('billingLaborRate');
  if(tr){ const v = parseFloat(tr.value); out.default_tax_rate = Number.isFinite(v) ? Math.min(30, Math.max(0, v)) : 0; }
  if(lr){ const v = parseFloat(lr.value); out.labor_rate = Number.isFinite(v) && v >= 0 ? v : null; }
  return out;
}
async function saveBillingProfile(){
  const btn = document.getElementById('saveBillingProfileBtn');
  btn.disabled = true; btn.textContent = 'Saving…';

  const fileInput = document.getElementById('billingLogoInput');
  const file = fileInput.files[0];
  let logoPathUpdate = {};
  if(file){
    if(file.size > 3*1024*1024){ relayNotice('Logo is too big — 3MB max.', { kind: 'info' }); btn.disabled=false; btn.textContent='Save billing info'; return; }
    const path = `${session.orgId}/${Date.now()}-${file.name}`;
    const { error: upErr } = await sb.storage.from('shop-logos').upload(path, file);
    if(upErr){ relayFail(upErr, 'Logo upload failed'); btn.disabled=false; btn.textContent='Save billing info'; return; }
    logoPathUpdate = { logo_path: path };
  }

  const { error } = await sb.from('organizations').update({
    billing_email: document.getElementById('billingEmail').value.trim() || null,
    billing_phone: document.getElementById('billingPhone').value.trim() || null,
    billing_address: document.getElementById('billingAddress').value.trim() || null,
    payment_instructions: document.getElementById('billingPaymentInstructions').value.trim() || null,
    ...(document.getElementById('billingInvoiceTerms') ? { invoice_terms: document.getElementById('billingInvoiceTerms').value.trim() || null } : {}),
    review_link: document.getElementById('billingReviewLink').value.trim() || null,
    ...billingRatesUpdate(),
    ...logoPathUpdate,
  }).eq('id', session.orgId);

  btn.disabled = false; btn.textContent = 'Save billing info';
  if(error){ relayFail(error, 'Could not save'); return; }
  fileInput.value = '';
  populateBillingForm();
  cachedReviewLink = document.getElementById('billingReviewLink').value.trim() || null;
  if(typeof refreshInvoices === 'function') refreshInvoices();
  relayNotice('Billing info saved.', { kind: 'info' });
}

// ================= inventory (price list) =================
async function fetchInventoryItems(){
  const { data, error } = await sb.from('inventory_items')
    .select('id, name, description, unit_price, active')
    .eq('org_id', session.orgId).eq('active', true)
    .order('name', { ascending:true });
  if(error){ console.error('fetchInventoryItems', error); return []; }
  return data || [];
}

function inventoryItemCardHtml(item){
  return `<div class="job-card">
    <div class="job-card-top">
      <div><b>${esc(item.name)}</b>${item.description ? `<div class="meta">${esc(item.description)}</div>` : ''}</div>
      <b>$${Number(item.unit_price).toFixed(2)}</b>
    </div>
    <div style="margin-top:8px;"><button class="text-btn inv-item-delete-btn" data-id="${item.id}">Remove</button></div>
  </div>`;
}

async function refreshInventory(){
  const list = document.getElementById('inventoryList');
  if(!list) return;
  const items = await fetchInventoryItems();
  list.innerHTML = items.length ? items.map(inventoryItemCardHtml).join('') : '<div class="empty-note">No items yet — add your common services and parts on the right.</div>';
  list.querySelectorAll('.inv-item-delete-btn').forEach(btn=>{
    btn.onclick = async ()=>{
      if(!(await relayConfirm({ message: 'Remove this from your price list?' }))) return;
      const { error } = await sb.from('inventory_items').update({ active:false }).eq('id', Number(btn.dataset.id));
      if(error){ relayFail(error, 'Could not remove'); return; }
      refreshInventory();
      populateInventoryPicker();
    };
  });
}

async function addInventoryItem(){
  const name = document.getElementById('invItemName').value.trim();
  const description = document.getElementById('invItemDesc').value.trim();
  const priceRaw = document.getElementById('invItemPrice').value;
  const price = parseFloat(priceRaw);
  if(!name){ relayNotice('Enter a name.', { kind: 'info' }); return; }
  if(priceRaw === '' || isNaN(price) || price < 0){ relayNotice('Enter a valid price (0 or more).', { kind: 'info' }); return; }

  const btn = document.getElementById('addInventoryItemBtn');
  btn.disabled = true; btn.textContent = 'Adding…';
  const { error } = await sb.from('inventory_items').insert([{
    org_id: session.orgId, name, description: description || null, unit_price: price, created_by: session.id,
  }]);
  btn.disabled = false; btn.textContent = 'Add to price list';
  if(error){ relayFail(error, 'Could not add item'); return; }

  document.getElementById('invItemName').value = '';
  document.getElementById('invItemDesc').value = '';
  document.getElementById('invItemPrice').value = '';
  refreshInventory();
  populateInventoryPicker();
}

// Lets the invoice/estimate line-item form pull straight from the price
// list instead of retyping a description and price that's already saved.
async function populateInventoryPicker(){
  const picker = document.getElementById('invItemPicker');
  if(!picker) return;
  const items = await fetchInventoryItems();
  picker.innerHTML = '<option value="">+ Add from price list...</option>' +
    items.map(i => `<option value="${i.id}" data-name="${esc(i.name)}" data-price="${i.unit_price}">${esc(i.name)} — $${Number(i.unit_price).toFixed(2)}</option>`).join('');
}

function initInventoryUI(){
  // The Inventory tab is now built by inv.js (Phase 7); the old price-list
  // form only runs if its elements are on the page.
  const btn = document.getElementById('addInventoryItemBtn');
  if(!btn) return;
  refreshInventory();
  btn.onclick = addInventoryItem;
}

// ================= incoming work requests =================
let pendingAcceptRequestId = null; // set when "Accept" is clicked, consumed once the job is actually created

function setUpRequestLink(){
  const loc = typeof currentLocationId === 'function' ? currentLocationId() : null;
  const url = `${window.location.origin}/?request=${session.orgId}${loc ? '&loc=' + loc : ''}`;   // this location's own link
  const input = document.getElementById('requestLinkDisplay');
  if(input) input.value = url;
  const btn = document.getElementById('copyRequestLinkBtn');
  if(btn) btn.onclick = ()=>{
    navigator.clipboard.writeText(url).then(()=>{
      btn.textContent = 'Copied!';
      setTimeout(()=>{ btn.textContent = 'Copy link'; }, 1800);
    });
  };
}

async function fetchPendingWorkRequests(){
  // phone requests (migration 0053) carry their source, language, deadline and held slot; before 0053 the old fields still load
  const voiceCols = ', source, language, urgency, confirm_by, held_appointment_id, held:appointments!work_requests_held_appointment_id_fkey(starts_label, status)';
  let { data, error } = await sb.from('work_requests')
    .select('id, customer_name, company_name, customer_phone, customer_email, vehicle, issue_description, job_type, breakdown_lat, breakdown_lng, breakdown_address, eta_to_shop, photo_paths, created_at' + voiceCols)
    .eq('org_id', session.orgId).eq('status', 'pending')
    .order('created_at', { ascending:false });
  if(error && /source|held|language|relationship|column/i.test(error.message || '')){
    ({ data, error } = await sb.from('work_requests').select('id, customer_name, company_name, customer_phone, customer_email, vehicle, issue_description, job_type, breakdown_lat, breakdown_lng, breakdown_address, eta_to_shop, photo_paths, created_at').eq('org_id', session.orgId).eq('status', 'pending').order('created_at', { ascending:false }));
  }
  if(error){ console.error('fetchPendingWorkRequests', error); return []; }
  return data || [];
}

function workRequestCardHtml(req){
  const isInshop = req.job_type === 'inshop';
  const contact = [req.customer_phone, req.customer_email].filter(Boolean).join(' · ');
  const nameLine = req.company_name ? `${esc(req.customer_name)} — ${esc(req.company_name)}` : esc(req.customer_name);
  const isVoice = req.source === 'voice';
  const held = isVoice && req.held && req.held.status === 'held' ? req.held : null;
  const late = isVoice && req.confirm_by && new Date(req.confirm_by) < new Date();
  const typeDetail = isVoice
    ? `<div class="voice-req"><span class="voice-tag">${esc(relayFmt('AI phone call'))}${req.language === 'ru' ? ' · ' + esc(relayFmt('Russian')) : ''}${req.urgency === 'urgent' ? ' · <b>' + esc(relayFmt('Urgent')) + '</b>' : ''}</span>
        <span class="meta">${held ? esc(relayFmt('Held: {t}', { t: held.starts_label })) : esc(relayFmt('No time held'))}</span>
        ${req.confirm_by ? `<span class="meta${late ? ' voice-late' : ''}">${esc(relayFmt('Confirm by {t}', { t: new Date(req.confirm_by).toLocaleString(relayLocale(), { weekday: 'short', hour: 'numeric', minute: '2-digit' }) }))}</span>` : ''}</div>`
    : isInshop
      ? `<div class="meta" style="margin-top:4px;">Bringing it in: ${esc(req.eta_to_shop)}</div>`
      : `<div class="meta" style="margin-top:4px;">Location: ${esc(req.breakdown_address)}</div>`;
  return `<div class="job-card">
    <div class="job-card-top">
      <div><span class="doc-kind-tag">${isInshop ? 'IN-SHOP' : 'MOBILE'}</span><b>${nameLine}</b><div class="meta">${esc(req.vehicle)} · ${new Date(req.created_at).toLocaleString()}</div></div>
    </div>
    <div class="meta" style="margin-top:6px;">${esc(contact)}</div>
    ${typeDetail}
    <div style="margin-top:8px; font-size:0.85rem;">${esc(req.issue_description)}</div>
    ${(req.photo_paths || []).length ? `<div class="wreq-photos" data-paths="${esc(JSON.stringify(req.photo_paths))}"><span class="meta">Loading photos…</span></div>` : ''}
    <div style="margin-top:10px; display:flex; gap:8px;">
      ${held ? `<button class="text-btn wreq-confirm-btn" data-id="${req.id}">${esc(relayFmt('Confirm booking'))}</button><button class="text-btn wreq-release-btn" data-id="${req.id}">${esc(relayFmt('Release hold'))}</button>` : ''}
      <button class="text-btn wreq-accept-btn" data-id="${req.id}">Accept</button>
      <button class="text-btn wreq-decline-btn" data-id="${req.id}">Decline</button>
    </div>
  </div>`;
}

async function refreshWorkRequests(){
  const list = document.getElementById('workRequestsList');
  const badge = document.getElementById('workRequestsBadge');
  if(!list) return;
  const requests = await fetchPendingWorkRequests();
  list.innerHTML = requests.length ? requests.map(workRequestCardHtml).join('') : '<div class="empty-note">No pending requests.</div>';
  if(badge){
    if(requests.length){ badge.textContent = String(requests.length); badge.classList.remove('hidden'); }
    else badge.classList.add('hidden');
  }

  list.querySelectorAll('.wreq-photos').forEach(async box => {   // signed links, valid for an hour, only for this shop's staff
    let paths = []; try { paths = JSON.parse(box.dataset.paths || '[]'); } catch(_){}
    const { data, error } = await sb.storage.from('request-photos').createSignedUrls(paths, 3600);
    if(error || !data){ box.innerHTML = '<span class="meta">Photos could not be loaded.</span>'; return; }
    box.innerHTML = data.filter(d => d && d.signedUrl).map(d => `<a href="${esc(d.signedUrl)}" target="_blank" rel="noopener"><img src="${esc(d.signedUrl)}" alt="Photo from the customer" loading="lazy"></a>`).join('') || '<span class="meta">Photos could not be loaded.</span>';
  });
  // Declining needs a reason: the customer is emailed it. See openDeclineRequest (safety.js).
  list.querySelectorAll('.wreq-decline-btn').forEach(btn=>{
    btn.onclick = ()=> { if(typeof openDeclineRequest === 'function') openDeclineRequest(Number(btn.dataset.id), refreshWorkRequests); };
  });
  // phone requests: confirm the held time as a booking, or let it go
  list.querySelectorAll('.wreq-confirm-btn').forEach(btn => btn.onclick = async () => {
    btn.disabled = true; const { error: e } = await sb.rpc('confirm_voice_booking', { p_request: Number(btn.dataset.id) });
    if(e){ btn.disabled = false; relayFail(e, 'Could not confirm the booking'); return; }
    recordsToast(relayFmt('Booking confirmed. It is on the Schedule.')); refreshWorkRequests();
  });
  list.querySelectorAll('.wreq-release-btn').forEach(btn => btn.onclick = async () => {
    btn.disabled = true; const { error: e } = await sb.rpc('release_voice_hold', { p_request: Number(btn.dataset.id) });
    if(e){ btn.disabled = false; relayFail(e, 'Could not release the hold'); return; }
    recordsToast(relayFmt('Hold released')); refreshWorkRequests();
  });
  list.querySelectorAll('.wreq-accept-btn').forEach(btn=>{
    btn.onclick = ()=>{
      const req = requests.find(r => r.id === Number(btn.dataset.id));
      if(!req) return;
      pendingAcceptRequestId = req.id;
      const company = req.company_name ? ` (${req.company_name})` : '';
      document.getElementById('njCustomer').value = req.customer_name + company;
      document.getElementById('njVehicle').value = req.vehicle;
      const issueWithEta = req.job_type === 'inshop' ? `${req.issue_description}\n\nCustomer's ETA: ${req.eta_to_shop}` : req.issue_description;
      document.getElementById('njIssue').value = issueWithEta;

      if(typeof window.__setJobTypeUI === 'function') window.__setJobTypeUI(req.job_type);
      if(req.job_type === 'mobile' && req.breakdown_lat && typeof window.__setJobPin === 'function'){
        window.__setJobPin(req.breakdown_lat, req.breakdown_lng, `From request: ${req.breakdown_address}`);
        const addrInput = document.getElementById('addressInput');
        if(addrInput) addrInput.value = req.breakdown_address;
      }

      document.querySelector('[data-target="shop-jobs"]').click();
      relayNotice('Request details filled into the New Job form, including location and service type — just assign a mechanic and create the job.', { kind: 'info' });
    };
  });
}

function initWorkRequestsUI(){
  setUpRequestLink();
  refreshWorkRequests();
  everyWhileVisible(refreshWorkRequests, 120000);
}

function initBillingUI(){
  populateBillingForm();
  document.getElementById('billingLogoInput').onchange = ()=>{
    const file = document.getElementById('billingLogoInput').files[0];
    if(!file) return;
    const preview = document.getElementById('billingLogoPreview');
    preview.src = URL.createObjectURL(file);
    preview.style.display = 'block';
  };
  document.getElementById('saveBillingProfileBtn').onclick = saveBillingProfile;
}

// ================= feature announcements =================
// Add a new entry here whenever there's a new feature worth surfacing —
// each shows once per ACCOUNT until dismissed, oldest-undismissed first.
// Keyed by session.id, not just localStorage alone — a bare shared key
// would mean dismissing on one account (or even just loading the page as
// that account) suppresses the banner for every other account tested on
// the same browser afterward, which is exactly the bug this was hit by.
// Still genuinely a client-side, low-stakes "have they seen this" flag,
// not real app state — worst case on a new device, they see it again.
const ANNOUNCEMENTS = [
];

function announcementsStorageKey(){ return 'dismissedAnnouncements_' + session.id; }
function badgesStorageKey(){ return 'seenNewBadges_' + session.id; }

function renderAnnouncementBanner(){
  const banner = document.getElementById('announcementBanner');
  const textEl = document.getElementById('announcementText');
  if(!banner) return;
  let dismissed = [];
  try { dismissed = JSON.parse(localStorage.getItem(announcementsStorageKey()) || '[]'); } catch(e){ dismissed = []; }
  const next = ANNOUNCEMENTS.find(a => !dismissed.includes(a.id));
  if(!next){ banner.classList.add('hidden'); return; }
  textEl.innerHTML = icon('megaphone') + ' ' + esc(next.text);
  banner.dataset.id = next.id;
  banner.classList.remove('hidden');
}

function dismissAnnouncement(){
  const banner = document.getElementById('announcementBanner');
  const id = banner.dataset.id;
  if(!id) return;
  let dismissed = [];
  try { dismissed = JSON.parse(localStorage.getItem(announcementsStorageKey()) || '[]'); } catch(e){ dismissed = []; }
  if(!dismissed.includes(id)) dismissed.push(id);
  try { localStorage.setItem(announcementsStorageKey(), JSON.stringify(dismissed)); } catch(e){}
  renderAnnouncementBanner();
}

// NEW badges on tabs — hidden permanently (per account) the first time
// that tab is actually clicked, so it only ever draws attention once.
function initNewBadges(){
  let seen = [];
  try { seen = JSON.parse(localStorage.getItem(badgesStorageKey()) || '[]'); } catch(e){ seen = []; }
  const badgeTargets = [
    { tab: 'shop-invoices', badge: 'invoicesNewBadge' },
    { tab: 'shop-billing', badge: 'billingNewBadge' },
  ];
  badgeTargets.forEach(({ tab, badge }) => {
    const badgeEl = document.getElementById(badge);
    if(badgeEl && seen.includes(badge)) badgeEl.classList.add('hidden');
    const tabBtn = document.querySelector(`[data-target="${tab}"]`);
    if(tabBtn) tabBtn.addEventListener('click', () => {
      if(badgeEl) badgeEl.classList.add('hidden');
      let s = [];
      try { s = JSON.parse(localStorage.getItem(badgesStorageKey()) || '[]'); } catch(e){ s = []; }
      if(!s.includes(badge)){ s.push(badge); try { localStorage.setItem(badgesStorageKey(), JSON.stringify(s)); } catch(e){} }
    }, { once:true });
  });
}

// ================= full job history (paginated, searchable) =================
// Unlike the small "recent completed" snippet in the Jobs tab (capped at
// 20), this reaches every completed job a shop has ever had, a page at a
// time — org_id+status is already indexed (idx_jobs_org_status), so this
// stays fast even as history grows into the thousands.
const HISTORY_PAGE_SIZE = 25;
let historyOffset = 0;
let historyReachedEnd = false;

async function fetchJobHistoryPage({ orgId, search, jobType, offset, limit }){
  let q = sb.from('jobs').select(JOB_COLUMNS).eq('org_id', orgId).in('status', DONE_STATUSES)
    .order('updated_at', { ascending:false }).range(offset, offset + limit - 1);
  if(jobType) q = q.eq('job_type', jobType);
  if(search) q = q.or(`customer.ilike.%${search}%,vehicle.ilike.%${search}%`);
  const { data, error } = await q;
  if(error){ console.error('fetchJobHistoryPage', error); return []; }
  return data || [];
}

function historyCardHtml(job, mechNameFn){
  const isInshop = job.job_type === 'inshop';
  return `<div class="job-card">
    <div class="job-card-top">
      <div>${isInshop ? '<span class="doc-kind-tag">IN-SHOP</span>' : ''}<b>${esc(job.customer)} — ${esc(job.vehicle)}</b><div class="meta">Mechanic: ${esc(mechNameFn(job.mechanic_id))} · ${new Date(job.updated_at).toLocaleDateString()}</div></div>
      ${jobStatusBadge(job.status)}
    </div>
    ${commentsBlockHtml(job.id)}
    ${attachmentsBlockHtml(job.id)}
  </div>`;
}

// Cached once per History-tab session rather than re-fetched on every
// page/search, since the mechanic roster rarely changes mid-browse.
let historyMechName = id => 'Unassigned';
async function refreshHistoryMechCache(){
  const mechanics = await fetchOrgMechanics();
  historyMechName = id => (mechanics.find(m=>m.id===id) || {}).name || 'Unassigned';
}

async function loadHistoryPage(reset){
  if(typeof cwLoad === 'function') return cwLoad(reset);
  const list = document.getElementById('fullHistoryList');
  const loadMoreBtn = document.getElementById('historyLoadMoreBtn');
  const endNote = document.getElementById('historyEndNote');
  if(reset){ historyOffset = 0; historyReachedEnd = false; list.innerHTML = ''; endNote.classList.add('hidden'); }

  const search = document.getElementById('historySearchInput').value.trim();
  const jobType = document.getElementById('historyTypeFilter').value;
  const page = await fetchJobHistoryPage({ orgId: session.orgId, search, jobType, offset: historyOffset, limit: HISTORY_PAGE_SIZE });

  if(page.length === 0 && historyOffset === 0){
    list.innerHTML = '<div class="empty-note">No completed jobs match.</div>';
    loadMoreBtn.classList.add('hidden');
    return;
  }

  const _s = preserveOpenChatNodes(list);
  list.insertAdjacentHTML('beforeend', page.map(job => historyCardHtml(job, historyMechName)).join(''));
  wireCommentToggles(list);
  wireAttachmentToggles(list);
  restoreOpenChatNodes(list, _s);

  historyOffset += page.length;
  historyReachedEnd = page.length < HISTORY_PAGE_SIZE;
  loadMoreBtn.classList.toggle('hidden', historyReachedEnd);
  endNote.classList.toggle('hidden', !historyReachedEnd || historyOffset === 0);
}

function initHistoryUI(){
  if(typeof initCompletedWork === 'function') return initCompletedWork();   // the new Completed work page (completed.js)
  let searchDebounce = null;
  document.getElementById('historySearchInput').addEventListener('input', ()=>{
    clearTimeout(searchDebounce);
    searchDebounce = setTimeout(()=> loadHistoryPage(true), 400);
  });
  document.getElementById('historyTypeFilter').onchange = ()=> loadHistoryPage(true);
  document.getElementById('historyLoadMoreBtn').onclick = ()=> loadHistoryPage(false);
  refreshHistoryMechCache().then(()=> loadHistoryPage(true));
}

function initShopView(){
  if(shopMap){ shopMap.remove(); shopMap = null; } // guards against initShopView running more than once per page session (e.g. sign-out then sign-in without a full reload)
  // The Overview no longer has a map (Dispatch has the live one), so only draw it if the box exists.
  if(document.getElementById('shopOpsMap')){ shopMap = L.map('shopOpsMap', { attributionControl:false }).setView([42.45, -83.25], 10); addBaseMapToggle(shopMap); }

  loadInviteCode();

  if(pinMapObj){ pinMapObj.remove(); pinMapObj = null; }
  pinMapObj = L.map('pinMap', { attributionControl:false }).setView([42.45, -83.25], 10);
  addBaseMapToggle(pinMapObj);
  pinMapObj.on('click', (e)=>{
    setPin(e.latlng.lat, e.latlng.lng, `Pin set at ${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`);
  });

  function setPin(lat, lng, hintText){
    chosenPin = { lat, lng };
    const latlng = [lat, lng];
    if(pinMarker) pinMarker.setLatLng(latlng); else pinMarker = L.marker(latlng, { icon: pinIcon('dest') }).addTo(pinMapObj);
    pinMapObj.setView(latlng, 15);
    document.getElementById('pinHint').textContent = hintText;
  }
  window.__setJobPin = setPin; // bridges to the accept-a-request flow, which lives outside this function's scope

  const addressInput = document.getElementById('addressInput');
  const addressBtn = document.getElementById('addressSearchBtn');
  const suggestBox = document.getElementById('addressSuggestions');

  function hideSuggestions(){ suggestBox.classList.add('hidden'); suggestBox.innerHTML = ''; }

  function renderSuggestions(results){
    if(!results || results.length === 0){ hideSuggestions(); return; }
    suggestBox.innerHTML = results.map((r, i) =>
      `<button type="button" class="address-suggestion" data-i="${i}">${esc(r.display_name)}</button>`
    ).join('');
    suggestBox.classList.remove('hidden');
    suggestBox.querySelectorAll('.address-suggestion').forEach(btn=>{
      btn.onclick = ()=>{
        const r = results[Number(btn.dataset.i)];
        addressInput.value = r.display_name; // fill with the exact match that was picked, not what was typed
        setPin(parseFloat(r.lat), parseFloat(r.lon), `Using: ${r.display_name}`);
        hideSuggestions();
      };
    });
  }

  // Nominatim's usage policy caps public requests at ~1/sec — debouncing
  // is required here, not just a nicety, or fast typing would get this
  // rate-limited (and every shop owner shares that same limit, since
  // they're all hitting the same public Nominatim instance).
  let addressDebounce = null;
  async function fetchSuggestions(query){
    if(!query || query.trim().length < 3){ hideSuggestions(); return; }
    try{
      const url = `https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&limit=5&q=${encodeURIComponent(query)}`;
      const res = await fetch(url, { headers: { 'Accept-Language': 'en' } });
      const results = await res.json();
      renderSuggestions(results);
    }catch(e){
      hideSuggestions();
    }
  }
  addressInput.addEventListener('input', ()=>{
    clearTimeout(addressDebounce);
    addressDebounce = setTimeout(()=> fetchSuggestions(addressInput.value), 450);
  });
  document.addEventListener('click', (e)=>{
    if(!suggestBox.contains(e.target) && e.target !== addressInput) hideSuggestions();
  });

  // The "Find" button / Enter key: an explicit trigger for anyone who'd
  // rather type the whole address and search than watch a live dropdown.
  // If there's exactly one match, that's unambiguous enough to use
  // directly; more than one, and it shows the same picker rather than
  // silently guessing which one was meant — that guess was the entire
  // original problem.
  async function searchAddress(){
    const query = addressInput.value.trim();
    if(!query) return;
    addressBtn.disabled = true;
    addressBtn.textContent = 'Searching…';
    document.getElementById('pinHint').textContent = 'Looking up that address...';
    try{
      const url = `https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&limit=5&q=${encodeURIComponent(query)}`;
      const res = await fetch(url, { headers: { 'Accept-Language': 'en' } });
      const results = await res.json();
      if(!results || results.length === 0){
        document.getElementById('pinHint').textContent = `Couldn't find "${query}" — try adding city and state, or drop the pin manually.`;
        hideSuggestions();
      } else if(results.length === 1){
        const r = results[0];
        addressInput.value = r.display_name;
        setPin(parseFloat(r.lat), parseFloat(r.lon), `Using: ${r.display_name}`);
        hideSuggestions();
      } else {
        document.getElementById('pinHint').textContent = `Found ${results.length} matches — pick the exact one below.`;
        renderSuggestions(results);
      }
    }catch(e){
      document.getElementById('pinHint').textContent = 'Address lookup failed — check your connection or drop the pin manually.';
    }
    addressBtn.disabled = false;
    addressBtn.textContent = 'Find';
  }

  addressBtn.onclick = searchAddress;
  addressInput.addEventListener('keydown', (e)=>{ if(e.key === 'Enter'){ e.preventDefault(); searchAddress(); } });

  let selectedJobType = 'mobile';
  function setJobTypeUI(type){
    selectedJobType = type;
    document.getElementById('jobTypeMobileBtn').classList.toggle('active', type === 'mobile');
    document.getElementById('jobTypeInshopBtn').classList.toggle('active', type === 'inshop');
    document.getElementById('njLocationField').classList.toggle('hidden', type === 'inshop');
    document.getElementById('njInshopNote').classList.toggle('hidden', type !== 'inshop');
  }
  window.__setJobTypeUI = setJobTypeUI; // bridges to the accept-a-request flow, same reason as __setJobPin above
  document.getElementById('jobTypeMobileBtn').onclick = ()=> setJobTypeUI('mobile');
  document.getElementById('jobTypeInshopBtn').onclick = ()=> setJobTypeUI('inshop');

  // Each of these is an independent feature area. Calling them in a flat,
  // un-isolated sequence means a single one throwing (a missing element,
  // a bad response shape, anything) silently stops every call after it
  // from ever running — which is exactly what broke the service-type
  // toggle above: it isn't related to any of these, but it was wired
  // AFTER them, so one of them failing was enough to take it down too.
  // Isolating each call means the rest of the page keeps working even
  // if one feature has a problem, and the real error still surfaces in
  // the console instead of disappearing.
  function safeInit(name, fn){
    try {
      const result = fn();
      if(result && typeof result.catch === 'function') result.catch(e => console.error(`${name} failed to initialize:`, e));
    } catch(e){ console.error(`${name} failed to initialize:`, e); }
  }
  safeInit('populateMechanicSelect', populateMechanicSelect);
  safeInit('populateFleetSelect', populateFleetSelect);
  safeInit('populateCompanyList', populateCompanyList);
  safeInit('refreshShopData', refreshShopData);
  safeInit('renderTeamList', renderTeamList);
  safeInit('initInvoicesUI', initInvoicesUI);
  safeInit('initInventoryUI', initInventoryUI);
  safeInit('initWorkRequestsUI', initWorkRequestsUI);
  safeInit('initBillingUI', initBillingUI);
  safeInit('initHistoryUI', initHistoryUI);
  if(typeof initRecordsUI === 'function') safeInit('initRecordsUI', initRecordsUI);
  if(typeof initInspectionsUI === 'function') safeInit('initInspectionsUI', initInspectionsUI);
  if(typeof initTimeUI === 'function') safeInit('initTimeUI', initTimeUI);
  if(typeof initUnitHistoryUI === 'function') safeInit('initUnitHistoryUI', initUnitHistoryUI);
  if(typeof initInventoryV2 === 'function') safeInit('initInventoryV2', initInventoryV2);
  if(typeof initAnalyticsV2 === 'function') safeInit('initAnalyticsV2', initAnalyticsV2);
  if(typeof initCommsUI === 'function') safeInit('initCommsUI', initCommsUI);
  if(typeof initRolesUI === 'function') safeInit('initRolesUI', initRolesUI);
  if(typeof initShopRedesign === 'function') safeInit('initShopRedesign', initShopRedesign);
  if(typeof initOpsUI === 'function') safeInit('initOpsUI', initOpsUI);
  if(typeof initDispatchUI === 'function') safeInit('initDispatchUI', initDispatchUI);
  if(typeof initQboUI === 'function') safeInit('initQboUI', initQboUI);
  if(typeof initAssist === 'function') safeInit('initAssist', initAssist);
  if(typeof initImportUI === 'function') safeInit('initImportUI', initImportUI);
  if(typeof initProfitUI === 'function') safeInit('initProfitUI', initProfitUI);
  if(typeof initLocations === 'function') safeInit('initLocations', initLocations);
  if(typeof initWoSheet === 'function') safeInit('initWoSheet', initWoSheet);
  if(typeof initNatasha === 'function') safeInit('initNatasha', initNatasha);
  if(typeof initPlansUI === 'function') safeInit('initPlansUI', initPlansUI);
  if(typeof renderSetupChecklist === 'function'){ safeInit('renderSetupChecklist', renderSetupChecklist); document.querySelectorAll('.dash-tab[data-target="shop-overview"]').forEach(t => t.addEventListener('click', renderSetupChecklist)); }
  safeInit('renderAnnouncementBanner', renderAnnouncementBanner);
  safeInit('initNewBadges', initNewBadges);
  safeInit('announcementDismissWiring', ()=>{ document.getElementById('announcementDismiss').onclick = dismissAnnouncement; });
  everyWhileVisible(refreshShopData, 120000); // fallback only - Realtime handles instant updates
  everyWhileVisible(() => { if(panelVisible('shop-team')) renderTeamList(); }, 120000);   // was every 15 s, always

  document.getElementById('createJobBtn').onclick = async ()=>{
    const customer = document.getElementById('njCustomer').value.trim();
    const vehicle = document.getElementById('njVehicle').value.trim();
    const issue = document.getElementById('njIssue').value.trim();
    const mechanicId = document.getElementById('njMechanic').value;
    const jobType = selectedJobType;
    if(!customer || !vehicle || !mechanicId){ relayNotice('Fill in customer, unit, and mechanic.', { kind: 'info' }); return; }
    if(jobType === 'mobile' && !chosenPin){ relayNotice('Set a breakdown location (address or pin) for a mobile job.', { kind: 'info' }); return; }

    const createBtn = document.getElementById('createJobBtn');
    createBtn.disabled = true;
    const unitTypeSel = document.getElementById('njUnitType');
    const rec = await resolveCustomerAndUnit(customer, vehicle, unitTypeSel ? unitTypeSel.value : 'trailer');
    // VIN from the form: saved to the unit (blanks only); never blocks creating the work order
    const vinIn = document.getElementById('njVin');
    if(vinIn && vinIn.value.trim() && rec && rec.unitId && typeof applyVinToUnit === 'function') await applyVinToUnit(rec.unitId, vinIn.value, window.njVinDecoded);
    if(rec.error){ createBtn.disabled = false; relayFail(rec.error); return; }
    const drivableVal = (document.getElementById('njDrivable') || {}).value;
    const fleetSel = document.getElementById('njFleet');
    const payload = {
      customer, vehicle, customer_id: rec.customerId, unit_id: rec.unitId,
      mechanic_id:mechanicId, job_type:jobType, status:'assigned', created_by:session.id, org_id:session.orgId,
      fleet_profile_id: fleetSel && fleetSel.value ? fleetSel.value : null,
      complaint: issue || null,
      priority: (document.getElementById('njPriority') || {}).value || 'normal',
      safety_issue: !!(document.getElementById('njSafety') || {}).checked,
      drivable: drivableVal === 'yes' ? true : drivableVal === 'no' ? false : null
    };
    if(jobType === 'mobile'){ payload.dest_lat = chosenPin.lat; payload.dest_lng = chosenPin.lng; }
    const locSel = document.getElementById('njShopLoc'); if(locSel && locSel.value) payload.location_id = Number(locSel.value);

    const { data, error } = await sb.from('jobs').insert([payload]).select();
    createBtn.disabled = false;
    if(error){
      if(error.code === '42501') relayNotice("Could not create the job — you may be creating jobs too quickly, or the assigned mechanic may no longer be on your team. Wait a moment and try again, or refresh and check the mechanic list.", { kind: 'error', title: "Couldn't create the job" });
      else relayFail(error, 'Could not create job');
      return;
    }
    if(typeof notifyKick === 'function') notifyKick();


    if(pendingAcceptRequestId && data && data[0]){
      await sb.from('work_requests').update({
        status: 'accepted', reviewed_at: new Date().toISOString(), converted_job_id: data[0].id,
      }).eq('id', pendingAcceptRequestId);
      pendingAcceptRequestId = null;
      if(typeof refreshWorkRequests === 'function') refreshWorkRequests();
    }

    if(typeof woDraftClear === 'function') woDraftClear();   // the work order exists now; the draft is no longer needed
    { const vi = document.getElementById('njVin'); if(vi) vi.value = ''; const vm = document.getElementById('njVinMsg'); if(vm) vm.textContent = ''; window.njVinDecoded = null; }
    document.getElementById('njCustomer').value = ''; document.getElementById('njVehicle').value = ''; document.getElementById('njIssue').value = ''; addressInput.value = '';
    ['njPriority','njDrivable'].forEach(id => { const el = document.getElementById(id); if(el) el.selectedIndex = 0; });
    const safetyBox = document.getElementById('njSafety'); if(safetyBox) safetyBox.checked = false;
    if(pinMarker){ pinMapObj.removeLayer(pinMarker); pinMarker = null; } chosenPin = null;
    document.getElementById('pinHint').textContent = 'Type an address and hit Find, or click the map to drop a pin directly.';
    setJobTypeUI('mobile');
    refreshShopData();
    populateCompanyList();
    const cb = document.getElementById('woCreateBox'); if(cb) cb.classList.add('hidden');   // closes the sheet
    const nb = document.getElementById('woNewBtn'); if(nb) nb.textContent = '+ New work order';
  };
}

const AVAIL_ORDER = { available:0, busy:1, offline:2, off_duty:3 };
async function populateMechanicSelect(){
  const [mechanics, openJobs] = await Promise.all([
    fetchOrgMechanics().then(ms => ms.filter(m=>m.active)),
    sb.from('jobs').select('mechanic_id').eq('org_id', session.orgId).not('status','in','(' + CLOSED_STATUSES.join(',') + ')').then(r => r.data || [])
  ]);
  const load = {}; openJobs.forEach(j => { load[j.mechanic_id] = (load[j.mechanic_id] || 0) + 1; });
  mechanics.sort((a, b) => (AVAIL_ORDER[a.availability] ?? 2) - (AVAIL_ORDER[b.availability] ?? 2) || (load[a.id] || 0) - (load[b.id] || 0) || a.name.localeCompare(b.name));
  const label = m => {
    const bits = [{ available:'Available', busy:'Busy', off_duty:'Off duty', offline:'Offline' }[m.availability] || 'Offline'];
    if(m.skills && m.skills.length) bits.push(m.skills.slice(0, 3).join(', ') + (m.skills.length > 3 ? '…' : ''));
    bits.push((load[m.id] || 0) + ' open job' + ((load[m.id] || 0) === 1 ? '' : 's'));
    return esc(m.name) + ' — ' + esc(bits.join(' · '));
  };
  const sel = document.getElementById('njMechanic');
  sel.innerHTML = mechanics.map(m=>`<option value="${m.id}">${label(m)}</option>`).join('') || '<option value="">No active mechanics yet</option>';
}

async function populateCompanyList(){
  const [fleetCompanies, custRes] = await Promise.all([
    fetchCompanies(),
    sb.from('customers').select('company_name').eq('org_id', session.orgId).eq('active', true).order('company_name').limit(1000)
  ]);
  const names = (custRes.data || []).map(c => c.company_name);
  fleetCompanies.forEach(n => { if(!names.some(x => x.toLowerCase() === n.toLowerCase())) names.push(n); });
  document.getElementById('companyList').innerHTML = names.map(c=>`<option value="${esc(c)}"></option>`).join('');
  await populateUnitList();
}
// Units offered in the job form: the chosen customer's units, or all if none chosen.
async function populateUnitList(){
  const list = document.getElementById('unitList');
  if(!list) return;
  const customerName = (document.getElementById('njCustomer').value || '').trim();
  let q = sb.from('units').select('unit_number, unit_type, customer_id, customers(company_name)').eq('org_id', session.orgId).eq('active', true).order('unit_number').limit(1000);
  const { data } = await q;
  const rows = (data || []).filter(u => !customerName || (u.customers && u.customers.company_name.toLowerCase() === customerName.toLowerCase()));
  list.innerHTML = rows.map(u => `<option value="${esc(u.unit_number)}">${esc(u.unit_type)}${u.customers ? ' · ' + esc(u.customers.company_name) : ''}</option>`).join('');
}
// Escape % and _ so a customer or unit typed by a person is matched literally.
function ilikeExact(v){ return String(v).replace(/[\\%_]/g, m => '\\' + m); }
// Find the customer and unit records for what was typed on the job form,
// creating them if they are new. Returns { customerId, unitId } or { error }.
async function resolveCustomerAndUnit(customerName, unitNumber, unitType){
  customerName = customerName.trim(); unitNumber = unitNumber.trim();
  let { data: cust, error } = await sb.from('customers').select('id').eq('org_id', session.orgId).ilike('company_name', ilikeExact(customerName)).limit(1);
  if(error) return { error: 'Could not look up the customer: ' + error.message };
  let customerId = cust && cust[0] ? cust[0].id : null;
  if(!customerId){
    const ins = await sb.from('customers').insert([{ org_id: session.orgId, company_name: customerName }]).select('id');
    if(ins.error){
      const again = await sb.from('customers').select('id').eq('org_id', session.orgId).ilike('company_name', ilikeExact(customerName)).limit(1);
      if(again.data && again.data[0]) customerId = again.data[0].id;
      else return { error: 'Could not save the customer: ' + ins.error.message };
    } else customerId = ins.data[0].id;
  }
  const u = await sb.from('units').select('id, customer_id').eq('org_id', session.orgId).ilike('unit_number', ilikeExact(unitNumber)).limit(1);
  if(u.error) return { error: 'Could not look up the unit: ' + u.error.message };
  let unitId = null;
  if(u.data && u.data[0]){
    const unit = u.data[0];
    if(unit.customer_id && unit.customer_id !== customerId){
      return { error: `Unit "${unitNumber}" is already on file for a different customer. Check the unit number, or move the unit on the Units page.` };
    }
    unitId = unit.id;
    if(!unit.customer_id) await sb.from('units').update({ customer_id: customerId }).eq('id', unitId);
  } else if(unitType){
    const insU = await sb.from('units').insert([{ org_id: session.orgId, customer_id: customerId, unit_number: unitNumber, unit_type: unitType }]).select('id');
    if(insU.error) return { error: 'Could not save the unit: ' + insU.error.message };
    unitId = insU.data[0].id;
  }
  return { customerId, unitId };
}

async function renderTeamList(){
  const members = await fetchOrgMembers();
  const mechanics = members.filter(m=>m.role==='mechanic');
  const box = document.getElementById('teamList');

  function rowHtml(m){
    const sub = m.role === 'fleet'
      ? `Fleet manager · ${esc(m.company || 'no company set')}`
      : 'Mechanic';
    const mechExtra = m.role === 'mechanic' ? `<div class="team-skills">${typeof availChip === 'function' ? availChip(m.availability) : ''}${(m.skills || []).map(s => `<span class="rec-tag">${esc(s)}</span>`).join('')}<button type="button" class="text-btn team-skills-btn" data-id="${m.id}">${(m.skills || []).length ? 'Edit skills' : 'Add skills'}</button></div>` : '';
    return `
    <div class="team-row">
      <div><div class="tname">${esc(m.name)}</div><div class="tstatus">${sub} — ${m.active ? 'Active' : 'Deactivated'}</div>${mechExtra}</div>
      <button class="toggle-btn ${m.active ? 'on' : 'off'}" data-id="${m.id}" data-active="${m.active}">${m.active ? 'Active' : 'Inactive'}</button>
    </div>`;
  }

  box.innerHTML = `
    <div class="team-subhead">Mechanics</div>
    ${mechanics.length ? mechanics.map(rowHtml).join('') : '<div class="empty-note">No mechanics have signed up yet.</div>'}
    <div id="fleetCustomersBox"></div>
  `;
  renderFleetCustomers();

  box.querySelectorAll('.team-skills-btn').forEach(btn=>{
    btn.onclick = ()=>{ const m = mechanics.find(x=>x.id===btn.dataset.id); if(m && typeof openSkillsEditor === 'function') openSkillsEditor(m); };
  });
  box.querySelectorAll('.toggle-btn').forEach(btn=>{
    btn.onclick = async ()=>{
      const newActive = btn.dataset.active !== 'true';
      const { error } = await sb.from('profiles').update({ active:newActive }).eq('id', btn.dataset.id);
      if(!error){ renderTeamList(); populateMechanicSelect(); }
    };
  });
}

function jobEditRowHtml(job, mechanics, fleets){
  return `
    <div class="edit-grid">
      <input type="text" class="ej-customer" value="${esc(job.customer)}" placeholder="Customer">
      <input type="text" class="ej-vehicle" value="${esc(job.vehicle)}" placeholder="Vehicle">
      <select class="ej-mechanic">${mechanics.map(m=>`<option value="${m.id}" ${m.id===job.mechanic_id?'selected':''}>${esc(m.name)}</option>`).join('')}</select>
      <select class="ej-fleet" title="Fleet customer account that can track this job">${fleetOptionsHtml(fleets || [], job.fleet_profile_id)}</select>
    </div>
    <div class="job-actions">
      <button class="ej-save">Save</button>
      <button class="ej-cancel">Cancel</button>
    </div>`;
}

function renderAnalytics(jobs, mechanics, mechName){
  // Replaced by analytics.js (Phase 8); kept only for pages without the new tab.
  if(!document.getElementById('analyticsBars')) return;
  const completed = jobs.filter(j => DONE_STATUSES.includes(j.status));
  const barsBox = document.getElementById('analyticsBars');
  const statsBox = document.getElementById('analyticsStats');
  if(!barsBox || !statsBox) return;

  if(completed.length === 0){
    barsBox.innerHTML = '<div class="empty-note">No completed jobs yet.</div>';
    statsBox.innerHTML = `<div class="stat-box"><b>0</b><span>Total completed</span></div>`;
    return;
  }

  const counts = {};
  completed.forEach(j => { counts[j.mechanic_id] = (counts[j.mechanic_id]||0) + 1; });
  const maxCount = Math.max(...Object.values(counts));
  const sorted = Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,8);
  barsBox.innerHTML = sorted.map(([id,count]) => `
    <div class="bar-row">
      <div class="bar-label">${esc(mechName(id))}</div>
      <div class="bar-track"><div class="bar-fill" style="width:${(count/maxCount*100).toFixed(0)}%"></div></div>
      <div class="bar-count">${count}</div>
    </div>`).join('');

  const durations = completed
    .filter(j => j.created_at && j.updated_at)
    .map(j => (new Date(j.updated_at) - new Date(j.created_at)) / 60000);
  const avgMin = durations.length ? Math.round(durations.reduce((a,b)=>a+b,0) / durations.length) : 0;
  const avgText = avgMin < 60 ? `${avgMin} min` : `${(avgMin/60).toFixed(1)} hrs`;
  const busiest = sorted[0] ? mechName(sorted[0][0]) : '—';

  statsBox.innerHTML = `
    <div class="stat-box"><b>${completed.length}</b><span>Total completed</span></div>
    <div class="stat-box"><b>${avgText}</b><span>Avg. time to complete</span></div>
    <div class="stat-box"><b>${esc(busiest)}</b><span>Busiest mechanic</span></div>`;
}

async function refreshShopData(){
  // Mechanics and jobs do not depend on each other: load them together, not one after the other.
  // recent completed work does not depend on them either, so it starts at the same time (it is only awaited later)
  const historyP = fetchCompletedJobs(60, { orgId: session.orgId });
  // positions carry their shop, so they are asked for by shop at the same time as everything else
  const [mechanics, active, locByOrg] = await Promise.all([fetchOrgMechanics(), fetchActiveJobs({ orgId: session.orgId }), fetchShopPositions()]);
  const locByMechanic = locByOrg || await fetchLocationsFor(mechanics.map(m=>m.id));   // older databases: by mechanic, as before

  let liveCount = 0;
  for(const m of mechanics){
    const loc = locByMechanic[m.id];
    if(!loc) continue;
    const isLive = Date.now() - loc.updatedAt < 30000;
    if(isLive) liveCount++;
    if(!shopMap) continue;
    if(shopMarkers[m.id]) shopMarkers[m.id].setLatLng([loc.lat, loc.lng]);
    else shopMarkers[m.id] = L.marker([loc.lat, loc.lng], { icon: pinIcon(isLive?'mech':'offline') }).addTo(shopMap).bindPopup(esc(m.name));
  }
  const countBadge = document.getElementById('shopMechCount');
  if(countBadge){ countBadge.style.display = 'inline-flex'; countBadge.innerHTML = `<span class="bd"></span>${liveCount} live`; }

  const mechName = id => (mechanics.find(m=>m.id===id) || {}).name || 'Unassigned';

  const history = await historyP;
  if(typeof renderTodayTiles === 'function') renderTodayTiles(active, mechanics, liveCount);

  // Shop board: open work orders plus the last 7 days of completed and invoiced ones.
  const board = document.getElementById('shopKanbanBoard');
  const weekAgo = Date.now() - 7 * 864e5;
  const recentDone = history.filter(j => ['complete','invoiced'].includes(j.status) && new Date(j.completed_at || j.updated_at).getTime() >= weekAgo);
  const boardJobs = active.concat(recentDone);
  const columns = {}; Object.keys(BOARD_COLUMNS).forEach(c => columns[c] = []);
  boardJobs.forEach(j => { columns[boardColumnFor(j.status)].push(j); });
  const metrics = typeof fetchBoardMetrics === 'function' ? await fetchBoardMetrics(boardJobs.map(j => j.id)) : {};
  const cardHtml = typeof woCardHtml === 'function' ? woCardHtml : (j => `<div class="job-card" data-job="${j.id}">${esc(j.customer)}</div>`);
  Object.keys(columns).forEach(col=>{
    const colList = document.getElementById('kanban-' + col);
    const countEl = document.getElementById('kanbanCount-' + col);
    if(!colList) return;
    const jobsInCol = columns[col].slice().sort((a, b) => new Date(b.updated_at || b.created_at) - new Date(a.updated_at || a.created_at));
    // only the cards that changed are redrawn (no flicker; drag and drop stays attached)
    patchChildren(colList, jobsInCol.map(j => ({ key: 'j' + j.id, html: cardHtml(j, mechName(j.mechanic_id), metrics[j.id] || {}) })), '<div class="kanban-empty">—</div>');
    if(countEl) countEl.textContent = String(jobsInCol.length);
  });
  if(board) wireKanbanDragDrop(board);
  // board filters: technician, roadside or in-shop, urgent only (kept across refreshes)
  if(typeof ensureBoardFilters === 'function'){
    ensureBoardFilters();
    const techNames = {}; boardJobs.forEach(j => { if(j.mechanic_id) techNames[j.mechanic_id] = mechName(j.mechanic_id); });
    refreshBoardTechs(techNames); applyBoardFilters();
  }
  if(typeof renderWorkOrdersList === 'function') renderWorkOrdersList(active, history, mechanics, metrics);

  // Redesign R1: shop.js draws "Recently completed" as compact rows.
  if(typeof renderWorkOrdersList !== 'function'){
  const histBox = document.getElementById('shopHistoryList');
  const _s2 = preserveOpenChatNodes(histBox);
  histBox.innerHTML = history.length === 0
    ? '<div class="empty-note">No completed jobs yet.</div>'
    : history.map(j => `
      <div class="job-card">
        ${roChipsHtml(j)}
        <div class="job-card-top"><div><b>${esc(j.customer)} — ${esc(j.vehicle)}</b><div class="meta">Mechanic: ${esc(mechName(j.mechanic_id))}</div></div>${jobStatusBadge(j.status)}</div>
        <div class="job-actions"><button class="j-open-ro" data-job="${j.id}">Open</button></div>
        ${commentsBlockHtml(j.id)}
        ${attachmentsBlockHtml(j.id)}
      </div>`).join('');
  wireCommentToggles(histBox);
  wireAttachmentToggles(histBox);
  restoreOpenChatNodes(histBox, _s2);
  }
}

// ================= FLEET MANAGER VIEW =================
const fleetMaps = {};
let fleetJobsByMechanic = {}; // mechanic_id -> [job.id, ...], used for realtime marker targeting
function initFleetView(){
  document.getElementById('fleetHint').textContent = `Showing units for ${session.company}, across every shop you've joined.`;
  loadFleetShops();
  if(typeof initFleetPortal === 'function') initFleetPortal();
  refreshFleetData();
  everyWhileVisible(refreshFleetData, 120000); // fallback only - Realtime handles instant updates
}

async function loadFleetShops(){
  const listBox = document.getElementById('fleetShopList');
  const { data, error } = await sb.from('fleet_shop_links').select('org_id, organizations(name)').eq('fleet_id', session.id);
  if(error || !data || data.length === 0){ listBox.innerHTML = '<div class="empty-note">You haven\'t joined any shops yet.</div>'; return; }
  listBox.innerHTML = data.map(l => `<span class="shop-chip">${icon('building')} ${esc(l.organizations ? l.organizations.name : 'Unknown shop')}</span>`).join('');
}

document.getElementById('fleetAddShopBtn').onclick = async ()=>{
  const errBox = document.getElementById('fleetAddShopError');
  const codeInput = document.getElementById('fleetAddShopCode');
  const code = codeInput.value.trim().toUpperCase();
  errBox.textContent = '';
  if(!code){ errBox.textContent = 'Enter an invite code.'; return; }

  // the shop's FLEET code (separate from its staff code); the database checks it and limits guesses
  const { data, error } = await sb.rpc('fleet_join_shop', { p_code: code });
  if(error){ errBox.textContent = friendlyError(error, 'Could not join').message; return; }
  if(data && data.error){ errBox.textContent = data.error; return; }
  if(typeof recordsToast === 'function') recordsToast('You are now a regular customer of ' + ((data && data.shop) || 'the shop'));
  codeInput.value = '';
  loadFleetShops();
  refreshFleetData();
};

async function refreshFleetData(){
  const orgs = await fetchAllOrganizations(); // RLS already limits this to orgs you've joined
  const orgIds = orgs.map(o=>o.id);
  const orgName = id => (orgs.find(o=>o.id===id) || {}).name || '—';
  const active = await fetchActiveJobs({ orgIds });
  const history = await fetchCompletedJobs(15, { orgIds });
  const locByMechanic = await fetchLocationsFor(active.map(j=>j.mechanic_id));
  const mechNames = typeof fleetMechanicNames === 'function' ? await fleetMechanicNames(active.map(j=>j.mechanic_id)) : {};

  fleetJobsByMechanic = {};
  active.forEach(j => {
    if(!fleetJobsByMechanic[j.mechanic_id]) fleetJobsByMechanic[j.mechanic_id] = [];
    fleetJobsByMechanic[j.mechanic_id].push(j.id);
  });

  const box = document.getElementById('fleetJobs');
  const _s1 = preserveOpenChatNodes(box);
  if(active.length === 0){ box.innerHTML = '<div class="card empty-note">No active jobs for your company right now.</div>'; }
  else {
    let html = '';
    for(const j of active){
      const isInshop = j.job_type === 'inshop';
      html += `<div class="card" style="margin-bottom:14px;">
        <div class="job-card-top"><div>${isInshop ? '<span class="doc-kind-tag">IN-SHOP</span>' : ''}<b>${esc(j.vehicle)}</b><div class="meta">Shop: ${esc(orgName(j.org_id))}${j.ro_number ? ' · ' + esc(j.ro_number) : ''}</div></div>${jobStatusBadge(j.status)}</div>
        <div class="job-actions"><button class="j-open-ro" data-job="${j.id}">Details</button></div>
        ${isInshop ? '<p class="meta" style="margin-top:10px;">This job is being done at the shop — no live location to track.</p>' : `
        <div class="ops-map" style="height:280px; margin-top:12px;" id="fleetMap${j.id}"></div>
        <div class="gps-readout" id="fleetDist${j.id}" style="margin-top:10px;"></div>`}
        ${commentsBlockHtml(j.id)}
        ${attachmentsBlockHtml(j.id)}
      </div>`;
    }
    box.innerHTML = html;
    wireCommentToggles(box);
    wireAttachmentToggles(box);
    restoreOpenChatNodes(box, _s1);

    for(const j of active){
      if(j.job_type === 'inshop') continue; // no destination — no map to build
      const loc = locByMechanic[j.mechanic_id];
      if(!fleetMaps[j.id]){
        const m = L.map('fleetMap'+j.id, { attributionControl:false }).setView([j.dest_lat, j.dest_lng], 12);
        addBaseMapToggle(m);
        L.marker([j.dest_lat, j.dest_lng], { icon: pinIcon('dest') }).addTo(m);
        fleetMaps[j.id] = { map:m, mechMarker:null };
      }
      const entry = fleetMaps[j.id];
      if(loc){
        if(entry.mechMarker) entry.mechMarker.setLatLng([loc.lat, loc.lng]);
        else entry.mechMarker = L.marker([loc.lat, loc.lng], { icon: pinIcon('mech') }).addTo(entry.map);
        const mi = milesBetween(loc.lat, loc.lng, j.dest_lat, j.dest_lng);
        const distEl = document.getElementById('fleetDist'+j.id);
        if(distEl) distEl.innerHTML = mi < 0.1
          ? `<b style="color:var(--done);">Technician has arrived at the location.</b>`
          : `${mechNames[j.mechanic_id] ? esc(mechNames[j.mechanic_id]) + ' is' : 'Technician is'} <b>${mi.toFixed(1)} miles</b> away${typeof fleetEtaText === 'function' ? ' · arriving <b>' + fleetEtaText(mi) + '</b>' : ''} · last updated <b>${new Date(loc.updatedAt).toLocaleTimeString()}</b>`;
      } else {
        const distEl = document.getElementById('fleetDist'+j.id);
        if(distEl) distEl.textContent = 'Waiting for technician to go live...';
      }
    }
  }

  const histBox = document.getElementById('fleetHistory');
  const _s2 = preserveOpenChatNodes(histBox);
  histBox.innerHTML = history.length === 0
    ? '<div class="card empty-note">No completed jobs yet.</div>'
    : history.map(j => `<div class="job-card">${roChipsHtml(j)}<div class="job-card-top"><div><b>${esc(j.vehicle)}</b><div class="meta">${esc(orgName(j.org_id))} · completed ${j.completed_at ? new Date(j.completed_at).toLocaleDateString() : '—'}</div></div>${jobStatusBadge(j.status)}</div><div class="job-actions"><button class="j-open-ro" data-job="${j.id}">Details</button></div>${commentsBlockHtml(j.id)}${attachmentsBlockHtml(j.id)}</div>`).join('');
  wireCommentToggles(histBox);
  wireAttachmentToggles(histBox);
  restoreOpenChatNodes(histBox, _s2);
  if(typeof refreshFleetPortal === 'function') refreshFleetPortal();
}

// ================= ADMIN VIEW =================
let adminOpsMap = null;
const adminMarkers = {};

function initAdminView(){
  if(adminOpsMap){ adminOpsMap.remove(); adminOpsMap = null; } // same guard as the other three view-init maps
  // The admin Overview shows the Shops on Relay map only; the live mechanics map was removed.
  if(document.getElementById('adminOpsMap')){ adminOpsMap = L.map('adminOpsMap', { attributionControl:false }).setView([42.45, -83.25], 9); addBaseMapToggle(adminOpsMap); }

  runAdminTabLoad('admin-overview');   // only the screen that is open loads
  everyWhileVisible(() => runAdminTabLoad(adminActiveTab()), 120000); // fallback only - Realtime handles instant updates
}

// Loads only the people screens (Accounts, Requests, Jobs), and only the one that is open.
// Overview, Shops, AI phone lines, Subscriptions and the rest load in runAdminTabLoad (admin-overview.js).
async function refreshAdminData(){
  const tab = adminActiveTab();
  if(!['admin-accounts','admin-requests','admin-jobs'].includes(tab)) return;
  const wantJobs = tab === 'admin-jobs';
  const wantAccounts = tab === 'admin-accounts';
  const [profiles, orgs, activeJobs] = await Promise.all([
    fetchAllProfiles(),
    fetchAllOrganizations(),
    wantJobs ? fetchActiveJobs() : Promise.resolve([])
  ]);
  const mechanics = profiles.filter(p=>p.role==='mechanic');
  const orgName = id => (orgs.find(o=>o.id===id) || {}).name || '—';
  const locByMechanic = adminOpsMap ? await fetchLocationsFor(mechanics.map(m=>m.id)) : {};   // only needed for the live map

  // Fleet managers can belong to multiple shops now — build the full list
  // per fleet manager instead of just showing their first/primary one.
  const { data: allFleetLinks } = wantAccounts ? await sb.from('fleet_shop_links').select('fleet_id, org_id').limit(5000) : { data: [] };
  const fleetShopsById = {};
  (allFleetLinks || []).forEach(l=>{
    if(!fleetShopsById[l.fleet_id]) fleetShopsById[l.fleet_id] = [];
    fleetShopsById[l.fleet_id].push(orgName(l.org_id));
  });



  // live map
  for(const m of mechanics){
    const loc = locByMechanic[m.id];
    if(!loc) continue;
    const isLive = Date.now() - loc.updatedAt < 30000;
    if(!adminOpsMap) continue;
    if(adminMarkers[m.id]) adminMarkers[m.id].setLatLng([loc.lat, loc.lng]);
    else adminMarkers[m.id] = L.marker([loc.lat, loc.lng], { icon: pinIcon(isLive?'mech':'offline') }).addTo(adminOpsMap).bindPopup(esc(m.name));
  }

  // accounts — only show members of approved companies (pending/rejected show under Requests instead)
  const approvedOrgIds = new Set(orgs.filter(o=>o.status==='approved').map(o=>o.id));
  const visibleProfiles = profiles.filter(p => p.role === 'admin' || approvedOrgIds.has(p.org_id));
  const accBox = document.getElementById('adminAccounts');

  function accountRowHtml(p, companyLine){
    return `
    <div class="account-row" data-id="${p.id}">
      <div class="aname">${esc(p.name)}<div class="meta" style="font-family:var(--font-mono); font-size:0.72rem; color:var(--ink-faint); margin-top:2px;">${companyLine}</div></div>
      <select class="arole-select">
        <option value="mechanic" ${p.role==='mechanic'?'selected':''}>Mechanic</option>
        <option value="shop" ${p.role==='shop'?'selected':''}>Shop owner</option>
        <option value="fleet" ${p.role==='fleet'?'selected':''}>Fleet manager</option>
        <option value="admin" ${p.role==='admin'?'selected':''}>Admin</option>
      </select>
      <input type="text" class="acompany-input" placeholder="Company (fleet only)" value="${esc(p.company||'')}">
      <div style="display:flex; gap:8px;">
        <button class="toggle-btn ${p.active?'on':'off'}" data-active="${p.active}">${p.active?'Active':'Inactive'}</button>
        <button class="j-edit acc-save">Save</button>
      </div>
    </div>`;
  }

  function renderAccountsForRole(role){
    const filtered = visibleProfiles.filter(p=>p.role===role);
    const companyLine = p =>
      role === 'shop' ? 'Company: ' + esc(orgName(p.org_id)) :
      role === 'mechanic' ? 'Works for: ' + esc(orgName(p.org_id)) :
      role === 'fleet' ? 'Customer of: ' + esc((fleetShopsById[p.id]||[]).join(', ') || orgName(p.org_id)) + ' · Company: ' + esc(p.company||'—') :
      'Platform admin';
    accBox.innerHTML = filtered.length
      ? filtered.map(p=>accountRowHtml(p, companyLine(p))).join('')
      : '<div class="empty-note">None yet.</div>';
    accBox.querySelectorAll('.account-row').forEach(row=>{
      const id = row.dataset.id;
      row.querySelector('.toggle-btn').onclick = async (e)=>{
        const btn = e.target;
        const newActive = btn.dataset.active !== 'true';
        const { error } = await sb.from('profiles').update({ active:newActive }).eq('id', id);
        if(!error) refreshAdminData();
      };
      row.querySelector('.acc-save').onclick = async ()=>{
        const newRole = row.querySelector('.arole-select').value;
        const company = row.querySelector('.acompany-input').value.trim();
        const { error } = await sb.from('profiles').update({ role:newRole, company: newRole==='fleet' ? company : null }).eq('id', id);
        if(error) relayFail(error, 'Could not update'); else refreshAdminData();
      };
    });
  }

  const roleFilter = document.getElementById('accountsRoleFilter');
  renderAccountsForRole(roleFilter.value);
  roleFilter.onchange = ()=> renderAccountsForRole(roleFilter.value);


  // pending company requests
  const pendingOrgs = orgs.filter(o => o.status === 'pending');
  const reqBadge = document.getElementById('requestsBadge');
  if(pendingOrgs.length > 0){ reqBadge.textContent = pendingOrgs.length; reqBadge.classList.remove('hidden'); }
  else { reqBadge.classList.add('hidden'); }

  const reqBox = document.getElementById('adminRequests');
  if(pendingOrgs.length === 0){
    reqBox.innerHTML = '<div class="empty-note">No pending requests right now.</div>';
  } else {
    reqBox.innerHTML = pendingOrgs.map(org => {
      const owner = profiles.find(p => p.org_id === org.id && p.role === 'shop');
      return `
      <div class="request-card" data-org="${org.id}">
        <div class="rq-top">
          <div>
            <div class="rq-shop">${esc(org.name)}</div>
            <div class="rq-meta">
              Owner: ${esc(owner ? owner.name : 'Unknown')}<br>
              Email: ${esc(owner && owner.email ? owner.email : '—')}<br>
              Phone: ${esc(owner && owner.phone ? owner.phone : '—')}<br>
              Requested: ${new Date(org.created_at).toLocaleDateString()}
            </div>
          </div>
        </div>
        <div class="rq-actions">
          <button class="rq-approve">Approve</button>
          <button class="rq-reject">Reject</button>
        </div>
      </div>`;
    }).join('');

    reqBox.querySelectorAll('.request-card').forEach(card=>{
      const orgId = card.dataset.org;
      card.querySelector('.rq-approve').onclick = async ()=>{
        const { error } = await sb.from('organizations').update({ status:'approved' }).eq('id', orgId);
        if(error) relayFail(error, 'Could not approve'); else refreshAdminData();
      };
      card.querySelector('.rq-reject').onclick = async ()=>{
        if(!(await relayConfirm({ message: 'Reject this company\'s request? They will see a rejection message when they log in.' }))) return;
        const { error } = await sb.from('organizations').update({ status:'rejected' }).eq('id', orgId);
        if(error) relayFail(error, 'Could not reject'); else refreshAdminData();
      };
    });
  }

  // jobs
  const mechName = id => (profiles.find(p=>p.id===id) || {}).name || 'Unassigned';
  const active = activeJobs; // already fetched above for the stats
  const history = wantJobs ? await fetchCompletedJobs(30) : [];

  const list = document.getElementById('adminJobList');
  const _s1 = preserveOpenChatNodes(list);
  list.innerHTML = active.length === 0 ? '<div class="empty-note">No active jobs.</div>' : active.slice().reverse().map(j => `
    <div class="job-card" data-job="${j.id}">
      <div class="job-card-top">
        <div><b>${esc(j.customer)} — ${esc(j.vehicle)}</b><div class="meta">Mechanic: ${esc(mechName(j.mechanic_id))} · Company: ${esc(orgName(j.org_id))}</div></div>
        ${jobStatusBadge(j.status)}
      </div>
      <div class="job-actions">
        <button class="j-delete danger">Delete</button>
      </div>
      ${commentsBlockHtml(j.id)}
      ${attachmentsBlockHtml(j.id)}
    </div>`).join('');
  wireCommentToggles(list);
  wireAttachmentToggles(list);
  restoreOpenChatNodes(list, _s1);
  list.querySelectorAll('.j-delete').forEach(btn=>{
    btn.onclick = async ()=>{
      const jobId = Number(btn.closest('.job-card').dataset.job);
      if(!(await relayConfirm({ message: 'Delete this job?' }))) return;
      const { error } = await sb.from('jobs').delete().eq('id', jobId);
      if(!error) refreshAdminData();
    };
  });

  const adminHistBox = document.getElementById('adminHistoryList');
  const _s2 = preserveOpenChatNodes(adminHistBox);
  adminHistBox.innerHTML = history.length === 0
    ? '<div class="empty-note">No completed jobs yet.</div>'
    : history.map(j => `<div class="job-card"><div class="job-card-top"><div><b>${esc(j.customer)} — ${esc(j.vehicle)}</b><div class="meta">Mechanic: ${esc(mechName(j.mechanic_id))} · Company: ${esc(orgName(j.org_id))}</div></div>${jobStatusBadge(j.status)}</div>${commentsBlockHtml(j.id)}${attachmentsBlockHtml(j.id)}</div>`).join('');
  wireCommentToggles(adminHistBox);
  wireAttachmentToggles(adminHistBox);
  restoreOpenChatNodes(adminHistBox, _s2);

  // invoices — read-only here; admin uses the same View PDF the shop
  // uses, but paid/unpaid status and sending stay owned by the shop.
  const { data: allInvoices, error: allInvErr } = await sb.from('invoices')
    .select('doc_number, id, org_id, job_id, customer_name, customer_address, unit_number, status, notes, created_at, invoice_items(id, description, quantity, unit_price)')
    .order('created_at', { ascending:false })
    .limit(100);
  if(allInvErr) console.error('admin invoices fetch', allInvErr);
  const adminInvBox = document.getElementById('adminInvoiceList');
  if(!allInvoices || allInvoices.length === 0){
    adminInvBox.innerHTML = '<div class="empty-note">No invoices yet.</div>';
  } else {
    adminInvBox.innerHTML = allInvoices.map(inv => {
      const items = inv.invoice_items || [];
      const total = inv.total != null ? Number(inv.total) : items.reduce((sum, it)=> sum + Number(it.quantity) * Number(it.unit_price), 0);
      const unitTag = inv.unit_number ? `<div class="meta">Unit #${esc(inv.unit_number)}</div>` : '';
      return `<div class="job-card">
        <div class="job-card-top">
          <div><b>${esc(inv.customer_name)}</b><div class="meta">${esc(orgName(inv.org_id))} · $${total.toFixed(2)} · ${new Date(inv.created_at).toLocaleDateString()}</div></div>
          ${invoiceStatusBadge(inv.status)}
        </div>
        ${unitTag}
        <div style="margin-top:8px;"><button class="text-btn admin-inv-view-btn" data-id="${inv.id}">View PDF</button></div>
      </div>`;
    }).join('');
    adminInvBox.querySelectorAll('.admin-inv-view-btn').forEach(btn=>{
      btn.onclick = ()=> viewInvoicePdf(Number(btn.dataset.id));
    });
  }

  // error log
  const { data: errors } = await sb.from('error_logs').select('message, stack, page_url, user_role, created_at').order('created_at', { ascending:false }).limit(50);
  const errBadge = document.getElementById('errorsBadge');
  const recentErrors = (errors || []).filter(e => Date.now() - new Date(e.created_at).getTime() < 24*60*60*1000);
  if(recentErrors.length > 0){ errBadge.textContent = recentErrors.length; errBadge.classList.remove('hidden'); }
  else { errBadge.classList.add('hidden'); }

  const errBox = document.getElementById('adminErrors');
  errBox.innerHTML = (!errors || errors.length === 0) ? '<div class="empty-note">No errors logged. That\'s a good sign.</div>' :
    errors.map(er => `
      <div class="error-card">
        <div class="err-msg">${esc(er.message || 'Unknown error')}</div>
        <div class="err-meta">${new Date(er.created_at).toLocaleString()} · Role: ${esc(er.user_role||'—')} · Page: ${esc((er.page_url||'').split('/').pop() || '—')}</div>
        ${er.stack ? `<details><summary>Stack trace</summary><pre>${esc(er.stack)}</pre></details>` : ''}
      </div>`).join('');
}

// ================= theme toggle =================
(function initTheme(){
  const root = document.documentElement;
  const saved = localStorage.getItem('relay_theme');
  const theme = saved || 'light';
  if(theme === 'dark') root.setAttribute('data-theme', 'dark');

  const btn = document.getElementById('themeToggle');
  const knob = btn.querySelector('.knob');
  knob.innerHTML = theme === 'dark' ? icon('moon', 14) : icon('sun', 14);

  btn.onclick = ()=>{
    const isDark = root.getAttribute('data-theme') === 'dark';
    if(isDark){ root.removeAttribute('data-theme'); knob.innerHTML = icon('sun', 14); localStorage.setItem('relay_theme','light'); }
    else{ root.setAttribute('data-theme','dark'); knob.innerHTML = icon('moon', 14); localStorage.setItem('relay_theme','dark'); }
  };
})();


// ---------- Team & time: the shop's regular fleet customers ----------
// Fleet accounts belong to the fleet manager, not to the shop: the shop never switches them on or off.
// The owner can remove a fleet from the regular customers, and shares the fleet code that adds new ones.
async function renderFleetCustomers(){
  const box = document.getElementById('fleetCustomersBox'); if(!box || !session || session.role !== 'shop') return;
  const isOwner = session.staffRole === 'owner';
  const { data, error } = await sb.rpc('shop_fleet_customers');
  if(error || !data){ box.innerHTML = '<div class="team-subhead">Regular fleet customers</div>' + (error && /Only the shop owner or office/.test(error.message) ? '' : `<p class="form-error">${esc(friendlyError(error, 'Could not load your fleet customers').message)}</p>`); return; }
  const fleets = data.fleets || [];
  const day = v => v ? new Date(v).toLocaleDateString(relayLocale(), { year: 'numeric', month: 'short', day: 'numeric' }) : '';
  box.innerHTML = `<div class="team-subhead">Regular fleet customers</div>
    <p class="meta">Fleet managers open their own Relay account, find you under Find shops, and become your regular customer with your fleet code. You can remove a fleet from this list; their own account stays theirs.</p>
    ${isOwner ? `<div class="fleet-code-box"><div><span class="meta">${typeof relayLocations !== 'undefined' && relayLocations.length > 1 && typeof chosenLocation === 'function' && chosenLocation() ? 'Fleet code for ' + esc(locDisplayName(chosenLocation())) : 'Your fleet code'}</span><b class="mono" id="fleetCodeVal">${esc(data.fleet_code || '')}</b></div>
      <div class="job-actions" style="margin-top:0;"><button type="button" class="ghost-btn" id="fleetCodeCopy">Copy</button><button type="button" class="text-btn" id="fleetCodeNew">Make a new code</button></div></div>
      <p class="meta">Share it only with fleets you want as customers. It is separate from the mechanic invite code, so a fleet can never use it to join your team.</p>` : ''}
    <p class="form-error" id="fleetCustErr"></p>
    ${fleets.length ? fleets.map(f => `<div class="team-row">
        <div><div class="tname">${esc(f.company || f.name || 'Fleet')}</div>
        <div class="tstatus">${esc([f.name && f.company ? f.name : '', f.email, f.phone].filter(Boolean).join(' · '))}</div>${f.since ? `<div class="tstatus">${esc(relayFmt('Customer since {d}', { d: day(f.since) }))}</div>` : ''}</div>
        ${isOwner ? `<button type="button" class="text-btn danger" data-fleetremove="${esc(f.fleet_id)}" data-name="${esc(f.company || f.name || 'this fleet')}">Remove</button>` : ''}
      </div>`).join('') : '<div class="empty-note">No regular fleet customers yet.</div>'}`;
  const err = m => { const e = document.getElementById('fleetCustErr'); if(e) e.textContent = m || ''; };
  const copy = document.getElementById('fleetCodeCopy');
  if(copy) copy.onclick = async () => { try { await navigator.clipboard.writeText(data.fleet_code); recordsToast('Fleet code copied'); } catch(_){ err('Could not copy automatically. Select the code and copy it.'); } };
  const nw = document.getElementById('fleetCodeNew');
  if(nw) nw.onclick = async () => {
    if(!(await relayConfirm({ message: 'Make a new fleet code? The old code stops working. Fleets that already joined stay your customers.', confirmText: 'Make a new code' }))) return;
    const { data: code, error: e2 } = await sb.rpc('new_fleet_invite_code');
    if(e2){ err(friendlyError(e2, 'Could not make a new code').message); return; }
    recordsToast('New fleet code ready'); renderFleetCustomers();
  };
  box.querySelectorAll('[data-fleetremove]').forEach(b => b.onclick = async () => {
    if(!(await relayConfirm({ message: 'Remove ' + b.dataset.name + ' from your regular customers? They keep their own Relay account, but no longer see your shop\'s work and invoices. They can join again with your fleet code.', confirmText: 'Remove', danger: true }))) return;
    const { error: e3 } = await sb.rpc('remove_fleet_customer', { p_fleet: b.dataset.fleetremove });
    if(e3){ err(friendlyError(e3, 'Could not remove the fleet').message); return; }
    recordsToast('Removed from your regular customers'); renderFleetCustomers();
  });
}
